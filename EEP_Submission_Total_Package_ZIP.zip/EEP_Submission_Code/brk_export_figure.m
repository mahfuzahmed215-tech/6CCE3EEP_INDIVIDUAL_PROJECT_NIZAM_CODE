function brk_export_figure(fig, outDir, baseName, cfg)
% brk_export_figure  Export a figure to PNG/PDF using exportgraphics.

if ~isfolder(outDir), mkdir(outDir); end

for k = 1:numel(cfg.exportFormats)
    fmt = lower(string(cfg.exportFormats(k)));
    outPath = fullfile(outDir, baseName + "." + fmt);

    if fmt == "png"
        exportgraphics(fig, outPath, "Resolution", cfg.exportDPI);
    elseif fmt == "pdf"
        exportgraphics(fig, outPath, "ContentType","vector");
    else
        saveas(fig, outPath);
    end
end
end
