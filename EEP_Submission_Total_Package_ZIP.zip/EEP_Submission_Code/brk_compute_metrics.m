function R = brk_compute_metrics(T, segments, cfg)
% brk_compute_metrics  Compute friction/thermal/kinematic metrics for each detected segment.
%
% Output table R has one row per segment (repetition).
%
% Metrics:
%   - μ mean, std, CV over steady window
%   - ΔT_max = Tmax − T0  (and robust ΔT_p95 = T95 − T0)
%   - distance over steady window
%   - mean load, mean RPM, nominal pressure (using cfg.specimenArea_m2)

nSeg = numel(segments);

R = table();
R.segmentID = (1:nSeg)';

% Preallocate
R.mu_mean = NaN(nSeg,1);
R.mu_std  = NaN(nSeg,1);
R.mu_cv_pct = NaN(nSeg,1);
R.mu_min = NaN(nSeg,1);
R.mu_max = NaN(nSeg,1);

R.load_mean_N = NaN(nSeg,1);
R.pressure_nom_MPa = NaN(nSeg,1);
R.rpm_mean = NaN(nSeg,1);
R.radius_m = NaN(nSeg,1);

R.distance_m = NaN(nSeg,1);

R.T0 = NaN(nSeg,1);
R.Tmax = NaN(nSeg,1);
R.dT_max = NaN(nSeg,1);
R.Tp = NaN(nSeg,1);
R.dT_p95 = NaN(nSeg,1);

R.isExcluded = false(nSeg,1);
R.exclusionReason = strings(nSeg,1);

for s = 1:nSeg
    idx = segments(s).idxSteady;
    if isempty(idx)
        R.isExcluded(s)=true;
        R.exclusionReason(s)="no steady indices";
        continue;
    end

    t = T.time_global_s(idx);
    mu = T.mu(idx);
    loadN = T.load_N(idx);
    rpm = T.rpm(idx);
    radius = median(T.radius_m(idx),"omitnan");

    % Decide temperature channel
    temp = brk_select_temperature_channel(T, idx, cfg);

    % Cleaning + filtering
    [muC, qcMu] = brk_clean_signal(mu, t, cfg);
    [tempC, ~]  = brk_clean_signal(temp, t, cfg);

    % Quality gate
    [exclude, reason] = brk_quality_gate(muC, qcMu, cfg);
    if exclude
        R.isExcluded(s)=true;
        R.exclusionReason(s)=reason;
    end

    % μ metrics
    R.mu_mean(s) = mean(muC,"omitnan");
    R.mu_std(s)  = std(muC,"omitnan");
    R.mu_cv_pct(s) = 100*R.mu_std(s)/R.mu_mean(s);
    R.mu_min(s) = min(muC,[],"omitnan");
    R.mu_max(s) = max(muC,[],"omitnan");

    % kinematics / load
    R.load_mean_N(s) = mean(loadN,"omitnan");
    if cfg.specimenArea_m2 > 0
        R.pressure_nom_MPa(s) = (R.load_mean_N(s) / cfg.specimenArea_m2) / 1e6;
    end
    R.rpm_mean(s) = mean(rpm,"omitnan");
    R.radius_m(s) = radius;

    % Distance over steady window
    if ismember("v_mps", T.Properties.VariableNames) && any(~isnan(T.v_mps(idx)))
        v = T.v_mps(idx);
        R.distance_m(s) = trapz(t, v);
    elseif ismember("s_global_m", T.Properties.VariableNames) && any(~isnan(T.s_global_m(idx)))
        sg = T.s_global_m(idx);
        R.distance_m(s) = sg(end) - sg(1);
    end

    % Temperature metrics
    if any(~isnan(tempC))
        t0 = segments(s).tSteadyStart;
        baseMask = (t >= t0) & (t < t0 + cfg.tempBaseline_s);
        if nnz(baseMask) < 3
            baseMask = true(size(tempC));
        end
        T0 = median(tempC(baseMask), "omitnan");
        Tmax = max(tempC, [], "omitnan");
        Tp = prctile(tempC, cfg.tempRobustPercentile);

        R.T0(s) = T0;
        R.Tmax(s) = Tmax;
        R.dT_max(s) = Tmax - T0;
        R.Tp(s) = Tp;
        R.dT_p95(s) = Tp - T0;
    end
end

end

% ======================= Helpers =========================
function temp = brk_select_temperature_channel(T, idx, cfg)
if cfg.tempChannel == "Tpad" && ismember("Tpad_C", T.Properties.VariableNames)
    temp = T.Tpad_C(idx);
    return;
end
if cfg.tempChannel == "Tdsk" && ismember("Tdsk_C", T.Properties.VariableNames)
    temp = T.Tdsk_C(idx);
    return;
end

% auto preference
if ismember("Tpad_C", T.Properties.VariableNames) && any(~isnan(T.Tpad_C(idx)))
    temp = T.Tpad_C(idx);
elseif ismember("Tdsk_C", T.Properties.VariableNames) && any(~isnan(T.Tdsk_C(idx)))
    temp = T.Tdsk_C(idx);
else
    temp = NaN(size(idx));
end
end

function [xOut, qc] = brk_clean_signal(x, t, cfg)
xOut = x;

qc = struct();
qc.n = numel(x);
qc.nanFracRaw = mean(isnan(xOut));

% Spike detection
if cfg.spikeDetection && any(~isnan(xOut))
    if cfg.spikeMethod == "mad"
        medx = median(xOut,"omitnan");
        madx = median(abs(xOut - medx),"omitnan");
        if madx == 0
            z = zeros(size(xOut));
        else
            z = 0.6745*(xOut - medx) / madx;
        end
        spikeMask = abs(z) > cfg.spikeThreshold;
    else
        mu = mean(xOut,"omitnan");
        sig = std(xOut,"omitnan");
        spikeMask = abs(xOut-mu) > cfg.spikeThreshold*sig;
    end
    qc.spikeFrac = mean(spikeMask & ~isnan(xOut));
    if cfg.replaceSpikesWithNaN
        xOut(spikeMask) = NaN;
    end
else
    qc.spikeFrac = 0;
end

% Moving mean
if cfg.applyMovingMean && numel(t) > 5
    dt = median(diff(t),"omitnan");
    if isnan(dt) || dt<=0, dt = 0.01; end
    winSamples = max(1, round(cfg.movingMeanWindow_s / dt));
    xOut = movmean(xOut, winSamples, "omitnan");
    qc.movmeanWinSamples = winSamples;
else
    qc.movmeanWinSamples = 0;
end

qc.nanFracClean = mean(isnan(xOut));
end

function [exclude, reason] = brk_quality_gate(mu, qcMu, cfg)
exclude = false;
reason = "";

if numel(mu) < cfg.minSegmentSamples
    exclude = true; reason = "too few samples in steady window"; return;
end
if qcMu.nanFracClean > cfg.maxNaNFracAllowed
    exclude = true; reason = "too many NaNs after cleaning"; return;
end
if all(isnan(mu))
    exclude = true; reason = "all μ samples are NaN"; return;
end
end
