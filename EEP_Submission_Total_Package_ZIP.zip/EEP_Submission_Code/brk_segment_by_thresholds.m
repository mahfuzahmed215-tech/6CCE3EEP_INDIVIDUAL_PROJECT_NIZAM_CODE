function segments = brk_segment_by_thresholds(T, cfg)
% brk_segment_by_thresholds  Detect steady-state segments using threshold rules.
%
% Each detected steady segment is treated as one 'repetition' (segmentID).
% Seating and ramp are included for plotting context but metrics are based on a
% steady sub-window (ignoring cfg.steadyIgnoreStart_s at the start).
%
% Requires columns: time_global_s, load_N, rpm.

t = T.time_global_s;
loadN = T.load_N;
rpm = T.rpm;

validLoad = loadN >= cfg.loadDetectMin_N & ~isnan(loadN);
validRPM  = rpm   >= cfg.speedDetectMin_RPM & ~isnan(rpm);

if ~any(validLoad)
    error("No samples above cfg.loadDetectMin_N; cannot segment.");
end
if ~any(validRPM)
    error("No samples above cfg.speedDetectMin_RPM; cannot segment.");
end

targetLoad = median(loadN(validLoad),"omitnan");
targetRPM  = median(rpm(validRPM),"omitnan");

steadyMask = (loadN >= cfg.loadSteadyFrac*targetLoad) & (rpm >= cfg.speedSteadyFrac*targetRPM);

% contiguous blocks
d = diff([false; steadyMask; false]);
iStart = find(d==1);
iEnd   = find(d==-1)-1;

segments = struct("segmentID",{}, "idxSeating",{}, "idxRamp",{}, "idxSteady",{}, "idxAll",{}, ...
    "tStart",{}, "tEnd",{}, "tSteadyStart",{}, "tSteadyEnd",{}, "targetLoad_N",{}, "targetRPM",{});

segID = 0;
for k = 1:numel(iStart)
    a = iStart(k);
    b = iEnd(k);
    if (t(b)-t(a)) < cfg.minSteadyDuration_s
        continue;
    end
    segID = segID + 1;

    % analysis steady window
    tSteadyStart = t(a) + cfg.steadyIgnoreStart_s;
    idxSteady = find(t >= tSteadyStart & t <= t(b));

    % engagement (20% load) defines beginning of segment window
    engageMask = loadN >= 0.2*targetLoad;
    iEng = find(engageMask(1:a), 1, "last");
    if isempty(iEng), iEng = max(1,a-1); end

    segments(segID).segmentID = segID;
    segments(segID).idxAll = (iEng:b)';
    segments(segID).idxSteady = idxSteady(:);
    segments(segID).idxRamp = (iEng:a-1)';
    segments(segID).idxSeating = (1:iEng-1)';

    segments(segID).tStart = t(iEng);
    segments(segID).tEnd = t(b);
    segments(segID).tSteadyStart = tSteadyStart;
    segments(segID).tSteadyEnd = t(b);

    segments(segID).targetLoad_N = targetLoad;
    segments(segID).targetRPM = targetRPM;
end

if isempty(segments)
    error("No steady segments found. Relax cfg.loadSteadyFrac / cfg.speedSteadyFrac or reduce cfg.minSteadyDuration_s.");
end
end
