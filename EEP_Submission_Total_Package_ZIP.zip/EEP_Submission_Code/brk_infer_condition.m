function cond = brk_infer_condition(fileName, cfg)
% brk_infer_condition  Infer texture + environment labels from filename (or optional map file).
%
% Default rules (case-insensitive):
%   - texture:
%       contains "NOTEXTURE" -> "flat"
%       contains "ONE" and "HOLE" -> "one-hole"
%       contains "TWO" and "HOLE" -> "two-hole"
%       else -> "unknown"
%   - environment:
%       contains "DRY" -> "dry"
%       contains "WET" -> "wet"
%       else -> "unknown"

fn = upper(string(fileName));

texture = "unknown";
if contains(fn, "NOTEXTURE")
    texture = "flat";
elseif contains(fn, "ONE") && contains(fn, "HOLE")
    texture = "one-hole";
elseif contains(fn, "TWO") && contains(fn, "HOLE")
    texture = "two-hole";
end

env = "unknown";
if contains(fn, "DRY")
    env = "dry";
elseif contains(fn, "WET")
    env = "wet";
end

cond = struct("texture", texture, "environment", env);
end
