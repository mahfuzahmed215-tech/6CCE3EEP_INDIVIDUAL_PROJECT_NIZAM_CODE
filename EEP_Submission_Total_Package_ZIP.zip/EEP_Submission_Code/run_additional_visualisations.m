%% =========================================================================
% run_additional_visualisations.m
% Additional visualisations for wet vs dry overlays, wet-cycle evolution,
% texture comparisons, and water-effect interpretation.
%
% Run this AFTER run_brakepad_analysis.m
%
% Requires in workspace:
%   rawData, allSeg, perCond, criteria, cfg, figDir
%
% Optional but expected:
%   CLR, TEX_KEYS, TEX_LABELS, TEX_COLORS, ENV_KEYS, ALPHA_REP
%% =========================================================================

if ~exist('rawData','var') || ~exist('allSeg','var') || ~exist('perCond','var') || ~exist('cfg','var')
    error(['Required workspace variables not found. Run run_brakepad_analysis.m first ' ...
           'or load the exported workspace before running this script.']);
end

if ~exist('figDir','var') || ~isfolder(figDir)
    figDir = fullfile(cfg.outDir,'figures');
    if ~isfolder(figDir), mkdir(figDir); end
end

%% -- FALLBACK STYLE VARIABLES ----------------------------------------------
if ~exist('CLR','var')
    CLR.dry = [0.85 0.33 0.10];
    CLR.wet = [0.13 0.47 0.71];
end

if ~exist('TEX_KEYS','var')
    TEX_KEYS   = ["flat","one-hole","two-hole"];
end

if ~exist('TEX_LABELS','var')
    TEX_LABELS = ["Flat (Baseline)","One-Hole","Two-Hole"];
end

if ~exist('TEX_COLORS','var')
    TEX_COLORS = [[0.40 0.40 0.40];
                  [0.18 0.63 0.36];
                  [0.56 0.12 0.82]];
end

if ~exist('ENV_KEYS','var')
    ENV_KEYS = ["dry","wet"];
end

if ~exist('ALPHA_REP','var')
    ALPHA_REP = [1.0, 0.75, 0.55];
end

%% -- HELPER SETTINGS -------------------------------------------------------
cycleNames = ["Cycle 1 (wettest)","Cycle 2 (dispersing)","Cycle 3 (near-dry)"];
cycleCols  = [0.10 0.40 0.90;
              0.15 0.70 0.30;
              0.82 0.25 0.25];

fprintf('\n=== Running additional visualisations ===\n');

%% =========================================================================
%% FIG 11 - DRY VS WET OVERLAY BY TEXTURE (ALL 3 REPETITIONS)
%% =========================================================================
fig11 = figure('Color','w','Position',[120 60 1100 820]);
tl11  = tiledlayout(fig11,3,1,'TileSpacing','compact','Padding','compact');
title(tl11,'Dry vs Wet Overlay by Texture - Friction Evolution','FontSize',13,'FontWeight','bold');

for ti = 1:3
    ax = nexttile(tl11); hold(ax,'on'); grid(ax,'on'); box(ax,'on'); ax.GridAlpha = 0.25;

    hDry = plot(ax, NaN, NaN, '-', 'Color', CLR.dry, 'LineWidth', 2.0, ...
        'DisplayName', 'Dry');
    hWet = plot(ax, NaN, NaN, '-', 'Color', CLR.wet, 'LineWidth', 2.0, ...
        'DisplayName', 'Wet');

    for ei = 1:2
        env = ENV_KEYS(ei);
        col = CLR.(char(env));

        fn_list = fieldnames(rawData);
        for fi = 1:numel(fn_list)
            d = rawData.(fn_list{fi});

            if string(d.cond.texture) == TEX_KEYS(ti) && string(d.cond.environment) == env
                T_    = d.T;
                segs  = d.segments;

                for si = 1:numel(segs)
                    idx = segs(si).idxSteady;
                    if isempty(idx), continue; end

                    t_  = T_.time_global_s(idx) - T_.time_global_s(idx(1));
                    mu_ = T_.mu(idx);

                    dt_ = median(diff(t_),'omitnan');
                    if isnan(dt_) || dt_ <= 0, dt_ = 0.01; end
                    win = max(1, round(cfg.movingMeanWindow_s/dt_));

                    muS = movmean(mu_, win, 'omitnan');

                    plot(ax, t_, muS, 'LineWidth', 1.4, ...
                        'Color', [col ALPHA_REP(si)], ...
                        'LineStyle', '-', ...
                        'HandleVisibility', 'off');
                end
                break;
            end
        end
    end

    title(ax, TEX_LABELS(ti), 'FontSize', 11, 'FontWeight', 'bold');
    xlabel(ax,'Time in braking event (s)');
    ylabel(ax,'\mu');
    legend(ax, [hDry hWet], {'Dry','Wet'}, 'Location','best');
end

brk_localSave_additional(fig11, figDir, 'Fig11_dry_wet_overlay_by_texture', cfg);

%% =========================================================================
%% FIG 12 - WET CYCLE EVOLUTION BY TEXTURE
%% =========================================================================
fig12 = figure('Color','w','Position',[130 70 1100 820]);
tl12  = tiledlayout(fig12,3,1,'TileSpacing','compact','Padding','compact');
title(tl12,'Wet Run Cycle Evolution - Water Dispersion Across Repetitions','FontSize',13,'FontWeight','bold');

for ti = 1:3
    ax = nexttile(tl12); hold(ax,'on'); grid(ax,'on'); box(ax,'on'); ax.GridAlpha = 0.25;

    fn_list = fieldnames(rawData);
    for fi = 1:numel(fn_list)
        d = rawData.(fn_list{fi});

        if string(d.cond.texture) == TEX_KEYS(ti) && string(d.cond.environment) == "wet"
            T_   = d.T;
            segs = d.segments;

            for si = 1:min(numel(segs),3)
                idx = segs(si).idxSteady;
                if isempty(idx), continue; end

                t_  = T_.time_global_s(idx) - T_.time_global_s(idx(1));
                mu_ = T_.mu(idx);

                dt_ = median(diff(t_),'omitnan');
                if isnan(dt_) || dt_ <= 0, dt_ = 0.01; end
                win = max(1, round(cfg.movingMeanWindow_s/dt_));

                muS = movmean(mu_, win, 'omitnan');

                plot(ax, t_, muS, ...
                    'Color', cycleCols(si,:), ...
                    'LineWidth', 1.7, ...
                    'DisplayName', char(cycleNames(si)));
            end
            break;
        end
    end

    title(ax, TEX_LABELS(ti), 'FontSize', 11, 'FontWeight', 'bold');
    xlabel(ax,'Time in braking event (s)');
    ylabel(ax,'\mu');
    legend(ax,'Location','best');
end

brk_localSave_additional(fig12, figDir, 'Fig12_wet_cycle_evolution', cfg);

%% =========================================================================
%% FIG 13 - TEXTURE COMPARISON WITHIN SAME ENVIRONMENT
%% Uses mean +/- SD band across 3 repetitions for each texture
%% =========================================================================
fig13 = figure('Color','w','Position',[140 80 1100 760]);
tl13  = tiledlayout(fig13,2,1,'TileSpacing','compact','Padding','compact');
title(tl13,'Texture Comparison Within Same Environment - Mean +/- 1SD','FontSize',13,'FontWeight','bold');

for ei = 1:2
    ax = nexttile(tl13); hold(ax,'on'); grid(ax,'on'); box(ax,'on'); ax.GridAlpha = 0.25;
    env = ENV_KEYS(ei);

    for ti = 1:3
        all_mu = {};
        fn_list = fieldnames(rawData);

        for fi = 1:numel(fn_list)
            d = rawData.(fn_list{fi});
            if string(d.cond.texture) == TEX_KEYS(ti) && string(d.cond.environment) == env
                T_   = d.T;
                segs = d.segments;

                for si = 1:numel(segs)
                    idx = segs(si).idxSteady;
                    if isempty(idx), continue; end

                    t_  = T_.time_global_s(idx) - T_.time_global_s(idx(1));
                    mu_ = T_.mu(idx);

                    dt_ = median(diff(t_),'omitnan');
                    if isnan(dt_) || dt_ <= 0, dt_ = 0.01; end
                    win = max(1, round(cfg.movingMeanWindow_s/dt_));

                    muS = movmean(mu_, win, 'omitnan');
                    all_mu{end+1} = struct('t',t_,'mu',muS); %#ok<SAGROW>
                end
                break;
            end
        end

        if isempty(all_mu), continue; end

        t_max = min(cellfun(@(x) x.t(end), all_mu));
        t_g   = (0:0.01:t_max)';

        mu_mat = NaN(numel(t_g), numel(all_mu));
        for r = 1:numel(all_mu)
            mu_mat(:,r) = interp1(all_mu{r}.t, all_mu{r}.mu, t_g, 'linear', 'extrap');
        end

        mu_avg = mean(mu_mat,2,'omitnan');
        mu_sd  = std(mu_mat,0,2,'omitnan');

        c_ = TEX_COLORS(ti,:);

        fill(ax, [t_g; flipud(t_g)], [mu_avg+mu_sd; flipud(mu_avg-mu_sd)], c_, ...
            'FaceAlpha', 0.12, 'EdgeColor', 'none', 'HandleVisibility', 'off');

        plot(ax, t_g, mu_avg, 'Color', c_, 'LineWidth', 2.2, ...
            'DisplayName', char(TEX_LABELS(ti)));
    end

    title(ax, sprintf('%s Environment', upper(char(env))), 'FontSize', 11, 'FontWeight', 'bold');
    xlabel(ax,'Time in braking event (s)');
    ylabel(ax,'\mu');
    legend(ax,'Location','best');
end

brk_localSave_additional(fig13, figDir, 'Fig13_texture_comparison_same_environment', cfg);

%% =========================================================================
%% FIG 14 - WATER-INDUCED FRICTION LOSS BY TEXTURE
%% =========================================================================
[mu_d, mu_w] = deal(NaN(3,1));
for ti = 1:3
    id = perCond.texture == TEX_KEYS(ti) & perCond.environment == "dry";
    iw = perCond.texture == TEX_KEYS(ti) & perCond.environment == "wet";

    if any(id), mu_d(ti) = perCond.mu_mean(find(id,1,'first')); end
    if any(iw), mu_w(ti) = perCond.mu_mean(find(iw,1,'first')); end
end

muLoss = mu_d - mu_w;

fig14 = figure('Color','w','Position',[180 120 760 460]);
ax14  = axes(fig14); hold(ax14,'on'); box(ax14,'on'); grid(ax14,'on'); ax14.GridAlpha = 0.25;

b = bar(ax14, muLoss, 'FaceColor', 'flat', 'EdgeColor', 'none');
for ti = 1:3
    b.CData(ti,:) = TEX_COLORS(ti,:);
end

for ti = 1:3
    if ~isnan(muLoss(ti))
        text(ax14, ti, muLoss(ti) + 0.02*max(muLoss,[],'omitnan'), sprintf('%.3f', muLoss(ti)), ...
            'HorizontalAlignment', 'center', 'FontSize', 9, 'FontWeight', 'bold');
    end
end

set(ax14,'XTick',1:3,'XTickLabel',TEX_LABELS,'FontSize',10.5);
ylabel(ax14,'\Delta\mu = \mu_{dry} - \mu_{wet}');
title(ax14,'Friction Loss Due to Water by Texture','FontSize',12,'FontWeight','bold');
subtitle(ax14,'Larger values indicate stronger wet sensitivity','FontSize',9,'Color',[0.4 0.4 0.4]);

brk_localSave_additional(fig14, figDir, 'Fig14_water_friction_loss', cfg);

%% =========================================================================
%% FIG 15 - WET CYCLE 1 vs CYCLE 3 DIRECT COMPARISON
%% =========================================================================
fig15 = figure('Color','w','Position',[160 70 1100 780]);
tl15  = tiledlayout(fig15,3,1,'TileSpacing','compact','Padding','compact');
title(tl15,'Wet Cycle 1 vs Cycle 3 - Initial Watered Contact vs Near-Dry Contact','FontSize',13,'FontWeight','bold');

for ti = 1:3
    ax = nexttile(tl15); hold(ax,'on'); grid(ax,'on'); box(ax,'on'); ax.GridAlpha = 0.25;

    fn_list = fieldnames(rawData);
    for fi = 1:numel(fn_list)
        d = rawData.(fn_list{fi});

        if string(d.cond.texture) == TEX_KEYS(ti) && string(d.cond.environment) == "wet"
            T_   = d.T;
            segs = d.segments;

            pickSeg = [1 3];
            pickCol = [0.10 0.40 0.90; 0.82 0.25 0.25];
            pickLab = {'Cycle 1 (water present)','Cycle 3 (nearly dry)'};

            for kk = 1:numel(pickSeg)
                si = pickSeg(kk);
                if si > numel(segs), continue; end

                idx = segs(si).idxSteady;
                if isempty(idx), continue; end

                t_  = T_.time_global_s(idx) - T_.time_global_s(idx(1));
                mu_ = T_.mu(idx);

                dt_ = median(diff(t_),'omitnan');
                if isnan(dt_) || dt_ <= 0, dt_ = 0.01; end
                win = max(1, round(cfg.movingMeanWindow_s/dt_));

                muS = movmean(mu_, win, 'omitnan');

                plot(ax, t_, muS, 'LineWidth', 2.0, ...
                    'Color', pickCol(kk,:), ...
                    'DisplayName', pickLab{kk});
            end
            break;
        end
    end

    title(ax, TEX_LABELS(ti), 'FontSize', 11, 'FontWeight', 'bold');
    xlabel(ax,'Time in braking event (s)');
    ylabel(ax,'\mu');
    legend(ax,'Location','best');
end

brk_localSave_additional(fig15, figDir, 'Fig15_wet_cycle1_vs_cycle3', cfg);

%% =========================================================================
%% FIG 16 - CYCLE-BY-CYCLE MEAN FRICTION FOR WET RUNS
%% =========================================================================
fig16 = figure('Color','w','Position',[190 110 860 500]);
ax16  = axes(fig16); hold(ax16,'on'); box(ax16,'on'); grid(ax16,'on'); ax16.GridAlpha = 0.25;

wetCycleMeans = NaN(3,3); % rows = texture, cols = cycle
for ti = 1:3
    fn_list = fieldnames(rawData);
    for fi = 1:numel(fn_list)
        d = rawData.(fn_list{fi});
        if string(d.cond.texture) == TEX_KEYS(ti) && string(d.cond.environment) == "wet"
            T_   = d.T;
            segs = d.segments;
            for si = 1:min(3,numel(segs))
                idx = segs(si).idxSteady;
                if isempty(idx), continue; end
                wetCycleMeans(ti,si) = mean(T_.mu(idx),'omitnan');
            end
            break;
        end
    end
end

bh = bar(ax16, wetCycleMeans, 'grouped');
for si = 1:3
    bh(si).FaceColor = cycleCols(si,:);
end

set(ax16,'XTick',1:3,'XTickLabel',TEX_LABELS,'FontSize',10.5);
ylabel(ax16,'Mean \mu');
title(ax16,'Wet Runs: Mean Friction by Cycle','FontSize',12,'FontWeight','bold');
subtitle(ax16,'Cycle 1 should reflect the strongest direct water effect','FontSize',9,'Color',[0.4 0.4 0.4]);
legend(ax16, cellstr(cycleNames), 'Location', 'best');

for ti = 1:3
    for si = 1:3
        xoff = bh(si).XEndPoints(ti);
        yval = wetCycleMeans(ti,si);
        if ~isnan(yval)
            text(ax16, xoff, yval + 0.02*max(wetCycleMeans(:),[],'omitnan'), sprintf('%.3f', yval), ...
                'HorizontalAlignment', 'center', 'FontSize', 8.5, 'FontWeight', 'bold');
        end
    end
end

brk_localSave_additional(fig16, figDir, 'Fig16_wet_cycle_mean_mu', cfg);

fprintf('=== Figs 11-16 complete ===\n');

%% =========================================================================
%% FIGS 17-24
%% =========================================================================

fprintf('\n=== Generating new Figs 17-24 ===\n');

%% =========================================================================
%% FIG 17 - TWO-WAY ANOVA EFFECT SIZES
%% Inlined - no dependency on brk_two_way_anova helper.
%% Uses MATLAB built-in anovan (Statistics & Machine Learning Toolbox).
%% =========================================================================
fprintf('  Fig17: ANOVA effect sizes...\n');
try
    % Build response + grouping vectors from allSeg
    validMask17 = ~allSeg.isExcluded;

    % Force numeric - table columns can be non-double
    y17 = double(allSeg.mu_mean(validMask17));

    % Force grouping to cell-of-char, which anovan strictly requires.
    % Handles string arrays, categorical, or cell inputs robustly.
    tex17raw = allSeg.texture(validMask17);
    env17raw = allSeg.environment(validMask17);
    if iscategorical(tex17raw), tex17raw = string(tex17raw); end
    if iscategorical(env17raw), env17raw = string(env17raw); end
    grpTex17 = cellfun(@char, cellstr(tex17raw), 'UniformOutput', false);
    grpEnv17 = cellfun(@char, cellstr(env17raw), 'UniformOutput', false);

    % Remove any rows where mu_mean is NaN
    nanMask17  = isnan(y17);
    y17        = y17(~nanMask17);
    grpTex17   = grpTex17(~nanMask17);
    grpEnv17   = grpEnv17(~nanMask17);

    % Two-way ANOVA with interaction
    % tbl17 cell rows: {header; Texture; Environment; Texture*Environment; Error; Total}
    [p17raw, tbl17, ~] = anovan(y17, {grpTex17, grpEnv17}, ...
        'model',    'interaction', ...
        'varnames', {'Texture','Environment'}, ...
        'display',  'off');

    % Pull SS values (column 2 of the cell table = Sum Sq)
    SS_tex = tbl17{2,2};
    SS_env = tbl17{3,2};
    SS_int = tbl17{4,2};
    SS_err = tbl17{5,2};

    SS_effects  = [SS_tex; SS_env; SS_int];
    pVals17     = p17raw(:);           % [Texture; Environment; Interaction]
    dispLabels  = {'Texture', 'Environment', 'Texture x Env'};
    nTerms      = 3;

    % Partial eta^2 = SS_effect / (SS_effect + SS_error)
    eta2vals = SS_effects ./ (SS_effects + SS_err);
    % Cohen's f = sqrt(eta^2 / (1 - eta^2))
    cohFvals = sqrt(max(eta2vals, 0) ./ max(1 - eta2vals, 1e-10));

    fig17 = figure('Color','w','Position',[100 80 1040 500]);
    tl17  = tiledlayout(fig17, 1, 2, 'TileSpacing','loose','Padding','compact');
    title(tl17, 'Two-Way ANOVA: Texture x Environment on \mu_{mean}', ...
          'FontSize',13,'FontWeight','bold');

    barCols17 = [0.22 0.47 0.70;
                 0.85 0.33 0.10;
                 0.47 0.67 0.19];

    pStr17 = @(p) char( ...
        (p <  0.001)              * "p<0.001" + ...
        (p >= 0.001 & p < 0.05)  * sprintf("p=%.3f",p) + ...
        (p >= 0.05)               * sprintf("p=%.3f (n.s.)",p) );

    % Left: partial eta-squared
    ax17a = nexttile(tl17);
    hold(ax17a,'on'); box(ax17a,'on'); grid(ax17a,'on'); ax17a.GridAlpha = 0.22;

    b17a = bar(ax17a, 1:nTerms, eta2vals, 'FaceColor','flat', 'EdgeColor','none', ...
               'BarWidth',0.55);
    for k = 1:min(nTerms,3), b17a.CData(k,:) = barCols17(k,:); end

    refLevels = [0.01 0.06 0.14];
    refLabels = {'Small (0.01)','Medium (0.06)','Large (0.14)'};
    for r = 1:3
        yline(ax17a, refLevels(r), '--', 'Color',[0.55 0.55 0.55], ...
              'LineWidth',0.9, 'Label',refLabels{r}, ...
              'LabelVerticalAlignment','bottom','FontSize',8, ...
              'HandleVisibility','off');
    end

    yPad = max(eta2vals) * 0.15;
    for k = 1:nTerms
        text(ax17a, k, eta2vals(k)+yPad*0.5, sprintf('%.3f',eta2vals(k)), ...
             'HorizontalAlignment','center','FontSize',9,'FontWeight','bold');
        if ~isnan(pVals17(k))
            text(ax17a, k, -0.045, pStr17(pVals17(k)), ...
                 'HorizontalAlignment','center','FontSize',7.5,'Color',[0.4 0.4 0.4]);
        end
    end

    set(ax17a,'XTick',1:nTerms,'XTickLabel',dispLabels,'FontSize',10.5, ...
              'YLim',[-0.08 min(1, max(eta2vals)+yPad*2)]);
    ylabel(ax17a,'Partial \eta^2');
    title(ax17a,'Partial \eta^2  (variance explained)','FontSize',11,'FontWeight','bold');

    % Right: Cohen's f
    ax17b = nexttile(tl17);
    hold(ax17b,'on'); box(ax17b,'on'); grid(ax17b,'on'); ax17b.GridAlpha = 0.22;

    b17b = bar(ax17b, 1:nTerms, cohFvals, 'FaceColor','flat', 'EdgeColor','none', ...
               'BarWidth',0.55);
    for k = 1:min(nTerms,3), b17b.CData(k,:) = barCols17(k,:); end

    fLevels = [0.10 0.25 0.40];
    fLabels = {'Small (0.10)','Medium (0.25)','Large (0.40)'};
    for r = 1:3
        yline(ax17b, fLevels(r), '--', 'Color',[0.55 0.55 0.55], ...
              'LineWidth',0.9, 'Label',fLabels{r}, ...
              'LabelVerticalAlignment','bottom','FontSize',8, ...
              'HandleVisibility','off');
    end

    yPadF = max(cohFvals) * 0.15;
    for k = 1:nTerms
        text(ax17b, k, cohFvals(k)+yPadF*0.5, sprintf('%.3f',cohFvals(k)), ...
             'HorizontalAlignment','center','FontSize',9,'FontWeight','bold');
    end

    set(ax17b,'XTick',1:nTerms,'XTickLabel',dispLabels,'FontSize',10.5, ...
              'YLim',[0 max(cohFvals)+yPadF*2]);
    ylabel(ax17b,"Cohen's f");
    title(ax17b,"Cohen's f  (practical effect magnitude)",'FontSize',11,'FontWeight','bold');

    brk_localSave_additional(fig17, figDir, 'Fig17_anova_effect_sizes', cfg);
catch ME
    warning('Fig17 skipped: %s', ME.message);
end

%% =========================================================================
%% FIG 18 - PERFORMANCE TRADE-OFF MAP  (mu vs Delta-T scatter)
%% =========================================================================
fprintf('  Fig18: Performance trade-off map...\n');
try
    fig18 = figure('Color','w','Position',[110 90 800 580]);
    ax18  = axes(fig18);
    hold(ax18,'on'); box(ax18,'on'); grid(ax18,'on'); ax18.GridAlpha = 0.22;

    flatDryMask = perCond.texture=="flat" & perCond.environment=="dry";
    mu_flat_dry = perCond.mu_mean(flatDryMask);
    dT_flat_dry = perCond.dT_max_mean(flatDryMask);

    zoneX = [mu_flat_dry*0.95, mu_flat_dry*1.05];
    zoneY = [0, dT_flat_dry];

    fill(ax18, [zoneX(1) zoneX(2) zoneX(2) zoneX(1)], ...
               [zoneY(1) zoneY(1) zoneY(2) zoneY(2)], ...
         [0.20 0.75 0.35], 'FaceAlpha',0.10, 'EdgeColor',[0.20 0.75 0.35], ...
         'LineStyle','--','LineWidth',1.2, ...
         'DisplayName','Target zone (+/-5% \mu, \DeltaT < flat)');

    text(ax18, mean(zoneX), zoneY(2)*0.45, 'Target zone', ...
         'FontSize',9,'Color',[0.10 0.60 0.25],'FontWeight','bold', ...
         'HorizontalAlignment','center');

    mkShapes  = {'o','s','d'};
    lblOffset = [-0.040  0.016;
                  0.015  0.016;
                 -0.040  0.016;
                 -0.040 -0.020;
                  0.015  0.016;
                  0.015  0.016];
    plotIdx = 0;

    for ti = 1:3
        for ei = 1:2
            plotIdx = plotIdx + 1;
            env18   = ENV_KEYS(ei);
            mask18  = perCond.texture==TEX_KEYS(ti) & perCond.environment==env18;
            if ~any(mask18), continue; end

            mu_v = perCond.mu_mean(mask18);
            dT_v = perCond.dT_max_mean(mask18);
            c18  = TEX_COLORS(ti,:);

            if env18 == "dry"
                scatter(ax18, mu_v, dT_v, 180, c18, mkShapes{ti}, 'filled', ...
                        'MarkerEdgeColor','k','LineWidth',0.5, ...
                        'DisplayName',sprintf('%s - Dry',char(TEX_LABELS(ti))));
            else
                scatter(ax18, mu_v, dT_v, 180, c18, mkShapes{ti}, ...
                        'LineWidth',2.0,'MarkerEdgeColor',c18, ...
                        'DisplayName',sprintf('%s - Wet',char(TEX_LABELS(ti))));
            end

            lbl18 = sprintf('%s / %s', char(TEX_LABELS(ti)), upper(char(env18)));
            text(ax18, mu_v + lblOffset(plotIdx,1), dT_v + lblOffset(plotIdx,2), lbl18, ...
                 'FontSize',8.5,'Color',c18*0.80,'FontWeight','bold');
        end
    end

    xlabel(ax18,'Mean Friction Coefficient (\mu)','FontSize',11);
    ylabel(ax18,'\DeltaT_{max} (deg C)','FontSize',11);
    title(ax18,'Performance Trade-off Map: Friction vs Thermal Response', ...
          'FontSize',12,'FontWeight','bold');
    subtitle(ax18,'Filled = Dry   |   Open = Wet   |   Green band = pass zone', ...
             'FontSize',9,'Color',[0.4 0.4 0.4]);
    legend(ax18,'Location','northeast','FontSize',9);

    brk_localSave_additional(fig18, figDir, 'Fig18_performance_tradeoff_map', cfg);
catch ME
    warning('Fig18 skipped: %s', ME.message);
end

%% =========================================================================
%% FIG 19 - STRIP PLOT  (condition means + individual segment points)
%% =========================================================================
fprintf('  Fig19: Strip plot...\n');
try
    fig19 = figure('Color','w','Position',[120 100 1000 520]);
    tl19  = tiledlayout(fig19,1,2,'TileSpacing','loose','Padding','compact');
    title(tl19,'Mean \mu with Individual Segment Points (Strip Plot)', ...
          'FontSize',13,'FontWeight','bold');

    for ei = 1:2
        ax19  = nexttile(tl19);
        hold(ax19,'on'); box(ax19,'on'); grid(ax19,'on'); ax19.GridAlpha = 0.22;
        env19 = ENV_KEYS(ei);
        col19 = CLR.(char(env19));

        for ti = 1:numel(TEX_KEYS)
            mask19  = perCond.texture==TEX_KEYS(ti) & perCond.environment==env19;
            if ~any(mask19), continue; end
            muMean19 = perCond.mu_mean(mask19);
            muSD19   = perCond.mu_sd(mask19);

            bar(ax19, ti, muMean19, 0.45, 'FaceColor',col19, ...
                'EdgeColor','none','FaceAlpha',0.35,'HandleVisibility','off');

            errorbar(ax19, ti, muMean19, muSD19, 'k', ...
                     'LineWidth',1.2,'CapSize',8,'HandleVisibility','off');

            segMask19 = allSeg.texture==TEX_KEYS(ti) & allSeg.environment==env19 ...
                        & ~allSeg.isExcluded;
            segVals19 = allSeg.mu_mean(segMask19);
            nPts19    = numel(segVals19);
            jitter19  = linspace(-0.12, 0.12, max(nPts19,1));

            for pp = 1:nPts19
                scatter(ax19, ti+jitter19(pp), segVals19(pp), 60, col19, ...
                        'filled','MarkerEdgeColor','k','MarkerEdgeAlpha',0.5, ...
                        'MarkerFaceAlpha',0.85,'HandleVisibility','off');
                text(ax19, ti+jitter19(pp), segVals19(pp)+0.005, ...
                     sprintf('rep%d',pp), 'FontSize',7.5, ...
                     'HorizontalAlignment','center','Color',[0.35 0.35 0.35]);
            end

            text(ax19, ti, muMean19+muSD19+0.025, sprintf('%.3f',muMean19), ...
                 'HorizontalAlignment','center','FontSize',9,'FontWeight','bold', ...
                 'Color',col19*0.75);
        end

        allEnvVals = allSeg.mu_mean(allSeg.environment==env19);
        set(ax19,'XTick',1:numel(TEX_KEYS),'XTickLabel',TEX_LABELS,'FontSize',10.5, ...
                 'YLim',[min(allEnvVals)*0.90, max(allEnvVals)*1.12]);
        ylabel(ax19,'Mean \mu (per segment)');
        title(ax19,sprintf('%s - bars = condition mean +/- 1SD',upper(char(env19))), ...
              'FontSize',11,'FontWeight','bold');
    end

    brk_localSave_additional(fig19, figDir, 'Fig19_strip_plot_segments', cfg);
catch ME
    warning('Fig19 skipped: %s', ME.message);
end

%% =========================================================================
%% FIG 20 - THERMAL EFFICIENCY INDEX
%% eta = DeltaT_max / (mu_mean * F_mean * d_mean)  [deg C / J]
%% =========================================================================
fprintf('  Fig20: Thermal efficiency index...\n');
try
    nCond20 = height(perCond);
    etaTh   = NaN(nCond20,1);
    for ci = 1:nCond20
        work_ci = perCond.mu_mean(ci) * perCond.load_mean_N(ci) * perCond.distance_mean_m(ci);
        if work_ci > 0
            etaTh(ci) = perCond.dT_max_mean(ci) / work_ci;
        end
    end

    fig20 = figure('Color','w','Position',[130 100 900 500]);
    ax20  = axes(fig20);
    hold(ax20,'on'); box(ax20,'on'); grid(ax20,'on'); ax20.GridAlpha = 0.22;

    bW20     = 0.30;
    envOff20 = [-0.20, +0.20];

    for ei = 1:2
        env20 = ENV_KEYS(ei);
        if env20=="dry", col20=CLR.dry; else, col20=CLR.wet; end

        for ti = 1:numel(TEX_KEYS)
            mask20 = perCond.texture==TEX_KEYS(ti) & perCond.environment==env20;
            if ~any(mask20), continue; end
            ci20 = find(mask20,1);
            val  = etaTh(ci20);
            if isnan(val), continue; end

            xp = ti + envOff20(ei);
            bc = bar(ax20, xp, val, bW20, 'FaceColor',col20, ...
                     'EdgeColor','none','FaceAlpha',0.85);
            if ti == 1
                bc.DisplayName = upper(char(env20));
            else
                bc.HandleVisibility = 'off';
            end

            text(ax20, xp, val + max(etaTh,[],'omitnan')*0.025, ...
                 sprintf('%.4f',val), ...
                 'HorizontalAlignment','center','FontSize',8.5,'FontWeight','bold');
        end
    end

    set(ax20,'XTick',1:numel(TEX_KEYS),'XTickLabel',TEX_LABELS,'FontSize',10.5);
    ylabel(ax20,'\DeltaT_{max} / (\mu \cdot F_n \cdot d)   [deg C / J]');
    title(ax20,'Thermal Efficiency Index by Texture and Environment', ...
          'FontSize',12,'FontWeight','bold');
    subtitle(ax20,'Lower = less heat per unit of braking work  (more thermally efficient)', ...
             'FontSize',9,'Color',[0.4 0.4 0.4]);
    legend(ax20,'Location','northeast');

    brk_localSave_additional(fig20, figDir, 'Fig20_thermal_efficiency_index', cfg);
catch ME
    warning('Fig20 skipped: %s', ME.message);
end

%% =========================================================================
%% FIG 21 - PROGRESSIVE DRIFT (repetition order effect)
%% =========================================================================
fprintf('  Fig21: Progressive drift...\n');
try
    fig21 = figure('Color','w','Position',[140 110 1100 480]);
    tl21  = tiledlayout(fig21,1,2,'TileSpacing','loose','Padding','compact');
    title(tl21,'Progressive Drift: Repetition Order Effect on \mu', ...
          'FontSize',13,'FontWeight','bold');

    for ei = 1:2
        ax21  = nexttile(tl21);
        hold(ax21,'on'); box(ax21,'on'); grid(ax21,'on'); ax21.GridAlpha = 0.22;
        env21 = ENV_KEYS(ei);

        for ti = 1:numel(TEX_KEYS)
            segMask21 = allSeg.texture==TEX_KEYS(ti) & allSeg.environment==env21 ...
                        & ~allSeg.isExcluded;
            seqVals   = allSeg.mu_mean(segMask21);
            seqIDs    = allSeg.segmentID(segMask21);
            [seqIDs, sIdx] = sort(seqIDs);
            seqVals   = seqVals(sIdx);
            if numel(seqVals) < 2, continue; end

            col21 = TEX_COLORS(ti,:);

            scatter(ax21, seqIDs, seqVals, 80, col21, 'filled', ...
                    'MarkerEdgeColor','k','MarkerEdgeAlpha',0.4, ...
                    'DisplayName',char(TEX_LABELS(ti)));

            p21   = polyfit(double(seqIDs), seqVals, 1);
            xFit  = [min(seqIDs)-0.3, max(seqIDs)+0.3];
            yFit  = polyval(p21, xFit);

            plot(ax21, xFit, yFit, '-', 'Color',col21, 'LineWidth',1.8, ...
                 'HandleVisibility','off');

            text(ax21, xFit(2)-0.1, yFit(2)+0.007, ...
                 sprintf('slope = %+.4f / rep', p21(1)), ...
                 'FontSize',8,'Color',col21*0.75, ...
                 'HorizontalAlignment','right','FontAngle','italic');
        end

        set(ax21,'XTick',1:3,'XTickLabel',{'Rep 1','Rep 2','Rep 3'},'FontSize',10.5);
        ylabel(ax21,'Mean \mu (per repetition)');
        title(ax21,sprintf('%s - run order effect',upper(char(env21))), ...
              'FontSize',11,'FontWeight','bold');
        legend(ax21,'Location','best');
    end

    brk_localSave_additional(fig21, figDir, 'Fig21_progressive_drift', cfg);
catch ME
    warning('Fig21 skipped: %s', ME.message);
end

%% =========================================================================
%% FIG 22 - EMPIRICAL CDF OF INSTANTANEOUS mu
%% =========================================================================
fprintf('  Fig22: Empirical CDF...\n');
try
    fig22 = figure('Color','w','Position',[150 120 1100 500]);
    tl22  = tiledlayout(fig22,1,2,'TileSpacing','loose','Padding','compact');
    title(tl22,'Empirical CDF of Instantaneous \mu - All Steady-State Samples', ...
          'FontSize',13,'FontWeight','bold');

    for ei = 1:2
        ax22  = nexttile(tl22);
        hold(ax22,'on'); box(ax22,'on'); grid(ax22,'on'); ax22.GridAlpha = 0.22;
        env22 = ENV_KEYS(ei);

        for ti = 1:numel(TEX_KEYS)
            allMuSamples = [];
            fn_list = fieldnames(rawData);

            for fi = 1:numel(fn_list)
                d = rawData.(fn_list{fi});
                if string(d.cond.texture)~=TEX_KEYS(ti) || ...
                   string(d.cond.environment)~=env22, continue; end
                T_   = d.T;
                segs = d.segments;
                for si = 1:numel(segs)
                    idx = segs(si).idxSteady;
                    if isempty(idx), continue; end
                    mu_ = T_.mu(idx);
                    allMuSamples = [allMuSamples; mu_(~isnan(mu_))]; %#ok<AGROW>
                end
            end

            if isempty(allMuSamples), continue; end

            [f22, x22] = ecdf(allMuSamples);
            plot(ax22, x22, f22, '-', 'Color',TEX_COLORS(ti,:), ...
                 'LineWidth',2.2,'DisplayName',char(TEX_LABELS(ti)));

            q1m  = quantile(allMuSamples,0.25);
            q3m  = quantile(allMuSamples,0.75);
            medm = median(allMuSamples);
            plot(ax22,[q1m q3m],[0.25 0.75],'x','Color',TEX_COLORS(ti,:), ...
                 'MarkerSize',7,'LineWidth',1.5,'HandleVisibility','off');
            plot(ax22,[medm medm],[0.45 0.55],'|','Color',TEX_COLORS(ti,:), ...
                 'MarkerSize',10,'LineWidth',2,'HandleVisibility','off');
        end

        for ql = [0.25 0.50 0.75]
            yline(ax22, ql, ':', 'Color',[0.65 0.65 0.65],'LineWidth',0.8, ...
                  'HandleVisibility','off');
        end

        xlabel(ax22,'Instantaneous \mu');
        ylabel(ax22,'Cumulative probability');
        title(ax22,sprintf('%s - steeper = more stable friction',upper(char(env22))), ...
              'FontSize',11,'FontWeight','bold');
        legend(ax22,'Location','southeast');
        ylim(ax22,[0 1]);
    end

    brk_localSave_additional(fig22, figDir, 'Fig22_mu_ecdf', cfg);
catch ME
    warning('Fig22 skipped: %s', ME.message);
end

%% =========================================================================
%% FIG 23 - MULTI-METRIC RADAR / SPIDER CHART
%% 5 normalised axes.  Outer edge = best in dataset.
%% Metrics (higher score = better after normalisation):
%%   1. Dry mu (higher = better)
%%   2. Wet mu (higher = better)
%%   3. Dry DeltaT_max (lower raw = higher score, inverted)
%%   4. Wet DeltaT_max (lower raw = higher score, inverted)
%%   5. Between-rep consistency (lower CV = higher score, inverted)
%% =========================================================================
fprintf('  Fig23: Radar chart...\n');
try
    nTex23 = numel(TEX_KEYS);
    rawM   = NaN(nTex23, 5);

    for ti = 1:nTex23
        maskDry = perCond.texture == TEX_KEYS(ti) & perCond.environment == "dry";
        maskWet = perCond.texture == TEX_KEYS(ti) & perCond.environment == "wet";

        if any(maskDry)
            rawM(ti,1) = perCond.mu_mean(find(maskDry,1));
            rawM(ti,3) = perCond.dT_max_mean(find(maskDry,1));
        end
        if any(maskWet)
            rawM(ti,2) = perCond.mu_mean(find(maskWet,1));
            rawM(ti,4) = perCond.dT_max_mean(find(maskWet,1));
        end
        if any(maskDry)
            rawM(ti,5) = perCond.mu_cv_between_pct(find(maskDry,1));
        end
    end

    % Normalise each metric to [0,1]; invert columns 3,4,5 (lower-is-better)
    normM = rawM;
    for col = 1:5
        col_min = min(rawM(:,col),[],'omitnan');
        col_max = max(rawM(:,col),[],'omitnan');
        rng23 = col_max - col_min;
        if rng23 == 0, rng23 = 1; end
        if ismember(col, [3 4 5])
            normM(:,col) = (col_max - rawM(:,col)) / rng23;
        else
            normM(:,col) = (rawM(:,col) - col_min) / rng23;
        end
    end

    axLabels23 = {'Dry \mu','Wet \mu','\DeltaT dry (inv)','\DeltaT wet (inv)','Consistency (inv)'};
    nAxes23    = numel(axLabels23);
    angles23   = linspace(0, 2*pi, nAxes23+1);
    angles23   = angles23(1:end-1);

    fig23 = figure('Color','w','Position',[160 130 700 620]);
    ax23  = axes(fig23,'Visible','off');
    hold(ax23,'on');
    ax23.DataAspectRatio = [1 1 1];

    % Reference circles
    for r = [0.25 0.50 0.75 1.00]
        xC = r * cos(angles23([1:end 1]));
        yC = r * sin(angles23([1:end 1]));
        plot(ax23, xC, yC, ':', 'Color',[0.78 0.78 0.78], 'LineWidth', 0.7);
        if r < 1.0
            text(ax23, r*cos(pi/2+0.05), r*sin(pi/2+0.05), sprintf('%.0f%%',r*100), ...
                 'FontSize',7.5,'Color',[0.55 0.55 0.55],'HorizontalAlignment','center');
        end
    end

    % Spokes and axis labels
    for a = 1:nAxes23
        plot(ax23, [0, cos(angles23(a))], [0, sin(angles23(a))], ...
             '-', 'Color',[0.70 0.70 0.70], 'LineWidth', 0.9);
        text(ax23, 1.18*cos(angles23(a)), 1.18*sin(angles23(a)), axLabels23{a}, ...
             'FontSize', 9.5, 'FontWeight','bold', ...
             'HorizontalAlignment','center','Color',[0.25 0.25 0.25]);
    end

    % Texture polygons
    for ti = 1:nTex23
        vals = normM(ti,:);
        xV   = vals .* cos(angles23);
        yV   = vals .* sin(angles23);
        xV   = [xV xV(1)];
        yV   = [yV yV(1)];
        c23  = TEX_COLORS(ti,:);

        fill(ax23, xV, yV, c23, 'FaceAlpha',0.12, 'EdgeColor',c23, ...
             'LineWidth',2.0, 'DisplayName',char(TEX_LABELS(ti)));
        scatter(ax23, xV(1:end-1), yV(1:end-1), 45, c23, 'filled', ...
                'MarkerEdgeColor','w','LineWidth',0.8,'HandleVisibility','off');
    end

    legend(ax23,'Location','southoutside','Orientation','horizontal','FontSize',10);
    title(ax23,'Multi-Metric Radar Chart - Normalised Performance', ...
          'FontSize',12,'FontWeight','bold');
    subtitle(ax23,'Outer edge = best in dataset per metric','FontSize',9,'Color',[0.4 0.4 0.4]);
    xlim(ax23,[-1.35 1.35]); ylim(ax23,[-1.35 1.35]);

    brk_localSave_additional(fig23, figDir, 'Fig23_radar_chart', cfg);
catch ME
    warning('Fig23 skipped: %s', ME.message);
end

%% =========================================================================
%% FIG 24 - SUMMARY BARS WITH 95% CI
%% Bootstrapped 95% CI from the 3 repetition means per condition.
%% =========================================================================
fprintf('  Fig24: Summary bars with 95%% CI...\n');
try
    fig24 = figure('Color','w','Position',[170 140 980 520]);
    tl24  = tiledlayout(fig24,1,2,'TileSpacing','loose','Padding','compact');
    title(tl24,'Mean \mu with 95% Confidence Intervals by Condition', ...
          'FontSize',13,'FontWeight','bold');

    nBoot24 = 5000;

    for ei = 1:2
        ax24  = nexttile(tl24);
        hold(ax24,'on'); box(ax24,'on'); grid(ax24,'on'); ax24.GridAlpha = 0.22;
        env24 = ENV_KEYS(ei);
        col24 = CLR.(char(env24));

        muCI_lo = NaN(numel(TEX_KEYS),1);
        muCI_hi = NaN(numel(TEX_KEYS),1);
        muMns   = NaN(numel(TEX_KEYS),1);

        for ti = 1:numel(TEX_KEYS)
            segMask24 = allSeg.texture==TEX_KEYS(ti) & allSeg.environment==env24 ...
                        & ~allSeg.isExcluded;
            repVals24 = allSeg.mu_mean(segMask24);

            if numel(repVals24) < 2
                muMns(ti) = mean(repVals24,'omitnan');
                continue;
            end

            bootMeans   = bootstrp(nBoot24, @mean, repVals24);
            muMns(ti)   = mean(repVals24);
            muCI_lo(ti) = muMns(ti) - quantile(bootMeans, 0.025);
            muCI_hi(ti) = quantile(bootMeans, 0.975) - muMns(ti);
        end

        bar(ax24, 1:numel(TEX_KEYS), muMns, 0.55, ...
            'FaceColor',col24,'EdgeColor','none','FaceAlpha',0.70);

        for ti = 1:numel(TEX_KEYS)
            if ~isnan(muCI_lo(ti))
                errorbar(ax24, ti, muMns(ti), muCI_lo(ti), muCI_hi(ti), 'k', ...
                         'LineWidth',1.3,'CapSize',9,'HandleVisibility','off');
            end
            if ~isnan(muMns(ti))
                yTxt = muMns(ti) + (muCI_hi(ti) + 0.03);
                text(ax24, ti, yTxt, sprintf('%.3f',muMns(ti)), ...
                     'HorizontalAlignment','center','FontSize',9,'FontWeight','bold', ...
                     'Color',col24*0.75);
            end
        end

        set(ax24,'XTick',1:numel(TEX_KEYS),'XTickLabel',TEX_LABELS,'FontSize',10.5);
        ylabel(ax24,'Mean \mu');
        title(ax24, sprintf('%s - error bars = 95%% CI (bootstrap, n=%d)', ...
              upper(char(env24)), nBoot24), ...
              'FontSize',11,'FontWeight','bold');
    end

    brk_localSave_additional(fig24, figDir, 'Fig24_summary_bars_95CI', cfg);
catch ME
    warning('Fig24 skipped: %s', ME.message);
end

fprintf('=== Additional visualisations complete. Saved to: %s ===\n', figDir);

%% =========================================================================
%% LOCAL SAVE HELPER
%% =========================================================================
function brk_localSave_additional(fig, outDir, name, cfg)
    if ~isfolder(outDir), mkdir(outDir); end

    % Suppress the axes-toolbar-visible export warning universally.
    % warning('off/on') works regardless of MATLAB version and layout type.
    warnID   = 'MATLAB:exportgraphics:axesToolbarVisible';
    prevWarn = warning('off', warnID);

    for k = 1:numel(cfg.exportFormats)
        fmt = lower(string(cfg.exportFormats{k}));
        p   = fullfile(outDir, name + "." + fmt);
        try
            if fmt == "png"
                exportgraphics(fig, p, 'Resolution', cfg.exportDPI);
            elseif fmt == "pdf"
                exportgraphics(fig, p, 'ContentType', 'vector');
            else
                saveas(fig, p);
            end
        catch ME
            warning('Save failed for %s: %s', name, ME.message);
        end
    end

    % Restore previous warning state
    warning(prevWarn);

    fprintf('  Saved: %s\n', name);
    close(fig);
end