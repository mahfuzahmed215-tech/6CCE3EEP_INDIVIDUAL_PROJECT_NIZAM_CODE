%% One Click Runner for Tribological & Thermal Analysis of Surface-Textured Automotive Brake Pads
%
%  Author    : Nizam Ahmed (K22016355)
%  Supervisor: Dr Sorin-Cristian Vlădescu
%  Platform  : Bruker UMT TriboLab, rotary pin-on-disc
%
%  TEST STRUCTURE (per CSV, 12 steps, 3 braking repetitions):
%    Step 1/5/9  – Spin-up:  no load, 1000 RPM, ~6.6 s
%    Step 2/6/10 – Engage:   25 N applied, 1000 RPM, ~0.2 s  (ramp)
%    Step 3/7/11 – Braking:  25 N, 1000→800 RPM, ~5.7 s     ← ANALYSIS
%    Step 4/8/12 – Unload:   ~1 N, 800 RPM, ~1.6 s
%
%  Notes:
%   - COF-T stored ×1000 by Bruker → auto-rescaled in brk_import_bruker_csv.
%   - Radius = 0.1298 m from Bruker metadata.
%   - brk_segment_by_thresholds reliably finds exactly 3 segments per file
%     (validated: each ~5.7 s at 25 N, 895 RPM mean).
%  
% SETUP INSTRUCTIONS:
%    1. Place ALL of the following in ONE folder:
%         - This file  (RUN_ALL_BRAKEPAD_ANALYSIS.m)
%         - run_brakepad_analysis.m
%         - run_additional_visualisations.m
%         - All brk_*.m helper functions
%         - All six TEST*.csv data files
%         - (Optional) wear_log.csv  if mass measurements are available
%
%    2. Open this file in MATLAB and press F5 (Run), OR type:
%         run('RUN_ALL_BRAKEPAD_ANALYSIS')
%       in the Command Window.
%
%    3. All outputs (figures + CSV tables) are written to:
%         <this folder>/analysis_out/
%% =========================================================================

clear; clc; close all;

%% ── Auto-detect project folder ────────────────────────────────────────────
thisFile      = mfilename('fullpath');
projectFolder = fileparts(thisFile);
if isempty(projectFolder)          % fallback when run from Command Window
    projectFolder = pwd;
end
fprintf('Project folder: %s\n', projectFolder);
addpath(projectFolder);
cd(projectFolder);

%% ── Check required files are present ─────────────────────────────────────
helpers = {'run_brakepad_analysis.m','run_additional_visualisations.m', ...
           'brk_default_config.m', ...
           'brk_import_bruker_csv.m','brk_infer_condition.m', ...
           'brk_segment_by_thresholds.m','brk_compute_metrics.m', ...
           'brk_summarise_conditions.m','brk_evaluate_success_criteria.m', ...
           'brk_two_way_anova.m','brk_plot_summary.m', ...
           'brk_plot_timeseries.m','brk_export_figure.m'};

csvs = {'TEST1-NOTEXTURE-DRY-REPETITION-25N-1000to800RPM.csv', ...
        'TEST1-NOTEXTURE-WET-REPETITION-25N-1000to800RPM.csv', ...
        'TEST2-ONE-HOLE-TEXTURE-DRY-REPETITION-25N-1000to800RPM.csv', ...
        'TEST2-ONE-HOLE-TEXTURE-WET-REPETITION-25N-1000to800RPM.csv', ...
        'TEST3-TWO-HOLE-TEXTURE-DRY-REPETITION-25N-1000to800RPM.csv', ...
        'TEST3-TWO-HOLE-TEXTURE-WET-REPETITION-25N-1000to800RPM.csv'};

all_files = [helpers, csvs];
missing   = all_files(~cellfun(@(f) isfile(fullfile(projectFolder,f)), all_files));

if ~isempty(missing)
    fprintf('\nMISSING FILES:\n');
    cellfun(@(f) fprintf('  - %s\n', f), missing);
    error('Please ensure all listed files are in:\n  %s', projectFolder);
end

fprintf('All required files found (%d helpers + %d CSV data files).\n', ...
    numel(helpers), numel(csvs));
fprintf('\nStarting analysis pipeline...\n\n');

%% ── Run the main pipeline ─────────────────────────────────────────────────
run_brakepad_analysis;

%% ── Run additional visualisations ─────────────────────────────────────────
fprintf('\n=== Running additional visualisations ===\n\n');
run_additional_visualisations;

fprintf('\n=== All pipelines complete ===\n');