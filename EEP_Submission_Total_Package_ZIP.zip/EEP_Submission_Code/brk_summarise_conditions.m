function perCond = brk_summarise_conditions(allSeg, cfg)
% brk_summarise_conditions  Group results by texture and environment.

T = allSeg;
if ismember("isExcluded", T.Properties.VariableNames)
    T = T(~T.isExcluded, :);
end

grp = findgroups(T.texture, T.environment);

perCond = table();
[perCond.texture, perCond.environment] = findgroups_to_labels(grp, T);

perCond.n = splitapply(@numel, T.segmentID, grp);

% μ stats (across repetitions)
perCond.mu_mean = splitapply(@(x) mean(x,"omitnan"), T.mu_mean, grp);
perCond.mu_sd   = splitapply(@(x) std(x,"omitnan"),  T.mu_mean, grp);
perCond.mu_cv_between_pct = 100*perCond.mu_sd ./ perCond.mu_mean;

% μ within-segment variability (averaged)
perCond.mu_within_sd_mean = splitapply(@(x) mean(x,"omitnan"), T.mu_std, grp);
perCond.mu_within_cv_mean_pct = splitapply(@(x) mean(x,"omitnan"), T.mu_cv_pct, grp);

% Temperature
if ismember("dT_max", T.Properties.VariableNames)
    perCond.dT_max_mean = splitapply(@(x) mean(x,"omitnan"), T.dT_max, grp);
    perCond.dT_max_sd   = splitapply(@(x) std(x,"omitnan"),  T.dT_max, grp);
end
if ismember("dT_p95", T.Properties.VariableNames)
    perCond.dT_p95_mean = splitapply(@(x) mean(x,"omitnan"), T.dT_p95, grp);
    perCond.dT_p95_sd   = splitapply(@(x) std(x,"omitnan"),  T.dT_p95, grp);
end

% Kinematics
perCond.distance_mean_m = splitapply(@(x) mean(x,"omitnan"), T.distance_m, grp);
perCond.load_mean_N = splitapply(@(x) mean(x,"omitnan"), T.load_mean_N, grp);
perCond.rpm_mean = splitapply(@(x) mean(x,"omitnan"), T.rpm_mean, grp);

% Wear (optional)
if ismember("k", T.Properties.VariableNames)
    perCond.k_mean = splitapply(@(x) mean(x,"omitnan"), T.k, grp);
    perCond.k_sd   = splitapply(@(x) std(x,"omitnan"),  T.k, grp);
end
if ismember("k_m", T.Properties.VariableNames)
    perCond.k_m_mean = splitapply(@(x) mean(x,"omitnan"), T.k_m, grp);
    perCond.k_m_sd   = splitapply(@(x) std(x,"omitnan"),  T.k_m, grp);
end

end

function [texture, environment] = findgroups_to_labels(grp, T)
u = unique(grp);
texture = strings(numel(u),1);
environment = strings(numel(u),1);
for i = 1:numel(u)
    idx = find(grp==u(i),1,"first");
    texture(i) = T.texture(idx);
    environment(i) = T.environment(idx);
end
end
