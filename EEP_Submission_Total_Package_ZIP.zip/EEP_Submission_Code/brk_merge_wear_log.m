function T = brk_merge_wear_log(T, cfg)
% brk_merge_wear_log  Merge external mass/density wear log and compute wear rates.
%
% Wear log columns expected:
%   file, segmentID, mass_before_mg, mass_after_mg, density_kg_m3 (optional)
%
% Outputs added:
%   delta_m_mg, deltaV_mm3, k (mm^3 / N m), k_m (mg / N m)

logT = readtable(cfg.wearLogPath);

% Normalise types
logT.file = string(logT.file);
T.file = string(T.file);

% Join on file+segmentID
T = outerjoin(T, logT, "Keys", ["file","segmentID"], "MergeKeys", true, "Type", "left");

% Compute mass loss
if ismember("mass_before_mg", T.Properties.VariableNames) && ismember("mass_after_mg", T.Properties.VariableNames)
    T.delta_m_mg = T.mass_before_mg - T.mass_after_mg;
else
    warning("Wear log missing mass_before_mg/mass_after_mg; skipping wear metrics.");
    return;
end

% Convert to wear volume if density available
hasRho = ismember("density_kg_m3", T.Properties.VariableNames) && any(~isnan(T.density_kg_m3));

T.deltaV_mm3 = NaN(height(T),1);
T.k = NaN(height(T),1);
T.k_m = NaN(height(T),1);

for i = 1:height(T)
    dm_mg = T.delta_m_mg(i);
    N = T.load_mean_N(i);
    s = T.distance_m(i);

    if isnan(dm_mg) || isnan(N) || isnan(s) || N<=0 || s<=0
        continue;
    end

    % mass-normalised wear rate (mg / N m)
    T.k_m(i) = dm_mg / (N*s);

    if hasRho && ~isnan(T.density_kg_m3(i)) && T.density_kg_m3(i) > 0
        rho = T.density_kg_m3(i);
        V_m3 = (dm_mg*1e-6) / rho;   % mg -> kg, then /rho
        V_mm3 = V_m3 * 1e9;
        T.deltaV_mm3(i) = V_mm3;
        T.k(i) = V_mm3 / (N*s);      % mm^3 / (N m)
    end
end

end
