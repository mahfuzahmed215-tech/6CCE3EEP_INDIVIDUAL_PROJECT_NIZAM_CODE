function fig = brk_plot_timeseries(T, segment, cfg, opts)
% brk_plot_timeseries  Create a 2×2 figure for one segment.
%
% Panels:
%   - μ vs time (shaded steady window)
%   - μ vs distance
%   - Temperature vs time
%   - Overlay of RPM, load, torque (scaled)

arguments
    T table
    segment struct
    cfg struct
    opts.titlePrefix string = ""
end

idxAll = segment.idxAll;
t = T.time_global_s(idxAll);
t0 = t(1);

% local time for nicer plots
tRel = t - t0;

mu = T.mu(idxAll);
loadN = T.load_N(idxAll);
rpm = T.rpm(idxAll);
torq = T.torque_Nm(idxAll);

% temp (auto)
temp = NaN(size(tRel));
if ismember("Tpad_C", T.Properties.VariableNames) && any(~isnan(T.Tpad_C(idxAll)))
    temp = T.Tpad_C(idxAll);
elseif ismember("Tdsk_C", T.Properties.VariableNames)
    temp = T.Tdsk_C(idxAll);
end

radius = median(T.radius_m(idxAll),"omitnan");
v = NaN(size(tRel));
if ~isnan(radius) && any(~isnan(rpm))
    v = 2*pi*radius.*(rpm/60);
end
s = cumtrapz(tRel, v);

% optional smoothing for display
if cfg.applyMovingMean && numel(tRel)>5
    dt = median(diff(tRel),"omitnan");
    if isnan(dt) || dt<=0, dt = 0.01; end
    win = max(1, round(cfg.movingMeanWindow_s/dt));
    muP = movmean(mu, win, "omitnan");
    tempP = movmean(temp, win, "omitnan");
    rpmP = movmean(rpm, win, "omitnan");
    loadP = movmean(loadN, win, "omitnan");
    torqP = movmean(torq, win, "omitnan");
else
    muP = mu; tempP=temp; rpmP=rpm; loadP=loadN; torqP=torq;
end

% steady window bounds in relative time
tSteadyA = segment.tSteadyStart - t0;
tSteadyB = segment.tSteadyEnd   - t0;

fig = figure("Color","w");
tiledlayout(fig,2,2,"TileSpacing","compact","Padding","compact");

% μ vs time
nexttile;
plot(tRel, muP, "LineWidth", 1.2); hold on;
brk_shade_window(tSteadyA, tSteadyB, ylim);
xlabel("Time (s)"); ylabel("\mu");
title(opts.titlePrefix + " | \mu vs time", "Interpreter","none");

% μ vs distance
nexttile;
plot(s, muP, "LineWidth", 1.2); hold on;
% shade corresponding window in distance domain
maskSteady = (tRel>=tSteadyA) & (tRel<=tSteadyB);
if any(maskSteady)
    brk_shade_window(s(find(maskSteady,1,"first")), s(find(maskSteady,1,"last")), ylim);
end
xlabel("Sliding distance, s (m)"); ylabel("\mu");
title("\mu vs distance");

% Temperature vs time
nexttile;
plot(tRel, tempP, "LineWidth", 1.2); hold on;
brk_shade_window(tSteadyA, tSteadyB, ylim);
xlabel("Time (s)"); ylabel("Temperature (\circC)");
title("Temperature vs time");

% Overlay (scaled)
nexttile;
% scale to comparable magnitudes using robust ranges
rpmS = brk_scale01(rpmP);
loadS = brk_scale01(loadP);
torqS = brk_scale01(torqP);

plot(tRel, rpmS, "LineWidth", 1.0); hold on;
plot(tRel, loadS, "LineWidth", 1.0);
plot(tRel, torqS, "LineWidth", 1.0);
brk_shade_window(tSteadyA, tSteadyB, ylim);
xlabel("Time (s)"); ylabel("Scaled signals (0–1)");
legend({"RPM","Load","Torque"}, "Location","best");
title("RPM / Load / Torque (scaled)");

end

function brk_shade_window(a,b,yl)
if isnan(a) || isnan(b) || b<=a, return; end
x = [a b b a];
y = [yl(1) yl(1) yl(2) yl(2)];
patch(x,y,[0.9 0.9 0.9], "EdgeColor","none", "FaceAlpha",0.4);
end

function z = brk_scale01(x)
p5 = prctile(x,5);
p95 = prctile(x,95);
if p95==p5
    z = zeros(size(x));
else
    z = (x - p5) / (p95-p5);
end
end
