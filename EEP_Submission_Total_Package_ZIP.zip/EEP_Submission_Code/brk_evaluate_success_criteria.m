function criteria = brk_evaluate_success_criteria(perCond, cfg)
% brk_evaluate_success_criteria  Apply dissertation success criteria:
%   - Wear reduction >= 15% relative to flat baseline (within same environment)
%   - |Δμ| <= 5% relative to flat baseline (within same environment)

criteria = perCond(:, ["texture","environment","n","mu_mean","mu_sd","mu_cv_between_pct"]);
criteria.mu_diff_pct_vs_flat = NaN(height(criteria),1);
criteria.mu_pass_5pct = false(height(criteria),1);

% Choose wear metric if present
hasK  = ismember("k_mean", perCond.Properties.VariableNames);
hasKm = ismember("k_m_mean", perCond.Properties.VariableNames);

criteria.wear_metric = strings(height(criteria),1);
criteria.wear_value  = NaN(height(criteria),1);
criteria.wear_reduction_pct = NaN(height(criteria),1);
criteria.wear_pass_15pct = false(height(criteria),1);

for e = unique(criteria.environment, "stable")'
    idxEnv = criteria.environment == e;

    % baseline row
    idxBase = idxEnv & criteria.texture == "flat";
    if ~any(idxBase)
        continue;
    end
    muBase = criteria.mu_mean(find(idxBase,1,"first"));

    for i = find(idxEnv)'
        mu = criteria.mu_mean(i);
        criteria.mu_diff_pct_vs_flat(i) = abs((mu - muBase)/muBase)*100;
        criteria.mu_pass_5pct(i) = criteria.mu_diff_pct_vs_flat(i) <= 5;
    end

    % wear baseline
    if hasK
        wBase = perCond.k_mean(find(idxBase,1,"first"));
        criteria.wear_metric(idxEnv) = "k (volume-based)";
        criteria.wear_value(idxEnv)  = perCond.k_mean(idxEnv);
    elseif hasKm
        wBase = perCond.k_m_mean(find(idxBase,1,"first"));
        criteria.wear_metric(idxEnv) = "k_m (mass-normalised)";
        criteria.wear_value(idxEnv)  = perCond.k_m_mean(idxEnv);
    else
        wBase = NaN;
    end

    if ~isnan(wBase) && wBase ~= 0
        for i = find(idxEnv)'
            w = criteria.wear_value(i);
            criteria.wear_reduction_pct(i) = (wBase - w)/wBase*100;
            criteria.wear_pass_15pct(i) = criteria.wear_reduction_pct(i) >= 15;
        end
    end
end

end
