%% =========================================================================
%  run_brakepad_analysis.m
%  Tribological & Thermal Analysis of Surface-Textured Automotive Brake Pads
%
%  Author    : Nizam Ahmed (K22016355)
%  Supervisor: Dr Sorin-Cristian Vlădescu
%  Platform  : Bruker UMT TriboLab, rotary pin-on-disc
%
%  TEST STRUCTURE (per CSV, 12 steps, 3 braking repetitions):
%    Step 1/5/9  – Spin-up:  no load, 1000 RPM, ~6.6 s
%    Step 2/6/10 – Engage:   25 N applied, 1000 RPM, ~0.2 s  (ramp)
%    Step 3/7/11 – Braking:  25 N, 1000→800 RPM, ~5.7 s     ← ANALYSIS
%    Step 4/8/12 – Unload:   ~1 N, 800 RPM, ~1.6 s
%
%  Notes:
%   - COF-T stored ×1000 by Bruker → auto-rescaled in brk_import_bruker_csv.
%   - Radius = 0.1298 m from Bruker metadata.
%   - brk_segment_by_thresholds reliably finds exactly 3 segments per file
%     (validated: each ~5.7 s at 25 N, 895 RPM mean).
%
%  OUTPUTS  →  ./analysis_out/
%    results_perSegment.csv      – one row per braking repetition
%    results_perCondition.csv    – grouped by texture × environment
%    success_criteria.csv        – Chapter 7.9 pass/fail evaluation
%    anova_mu_mean.csv           – two-way ANOVA for friction
%    anova_dT_max.csv            – two-way ANOVA for temperature rise
%    figures/Fig01 … Fig10       – PNG + PDF dissertation figures
%
%  USAGE:  run RUN_ALL_BRAKEPAD_ANALYSIS.m  (or this script directly)
%% =========================================================================

clear; clc;

%% ── 0. CONFIGURATION ──────────────────────────────────────────────────────
cfg = brk_default_config();

cfg.dataDir  = pwd;
cfg.outDir   = fullfile(cfg.dataDir, 'analysis_out');
cfg.wearLogPath = '';   % set to wear_log.csv path if available

% Geometry (override; also read from Bruker metadata)
cfg.trackRadius_m         = 0.1298;   % metres
cfg.useRadiusFromMetadata = true;
cfg.specimenArea_m2       = 1.0e-4;   % 10 mm × 10 mm  → p_nom = N/A [MPa]

% Signal quality
cfg.applyMovingMean      = true;
cfg.movingMeanWindow_s   = 0.20;
cfg.spikeDetection       = true;
cfg.spikeMethod          = 'mad';
cfg.spikeThreshold       = 6;
cfg.replaceSpikesWithNaN = true;
cfg.maxNaNFracAllowed    = 0.15;
cfg.minSegmentSamples    = 80;

% Segmentation  (validated against this 12-step dataset)
cfg.loadDetectMin_N      = 5;
cfg.speedDetectMin_RPM   = 100;
cfg.loadSteadyFrac       = 0.80;
cfg.speedSteadyFrac      = 0.60;   % RPM ramps 1000→800; wide tolerance needed
cfg.minSteadyDuration_s  = 3.0;
cfg.steadyIgnoreStart_s  = 0.40;   % skip engagement transient

% Temperature
cfg.tempChannel          = 'auto';
cfg.tempBaseline_s       = 0.30;
cfg.tempRobustPercentile = 95;

% Export
cfg.exportDPI     = 300;
cfg.exportFormats = {'png','pdf'};

%% ── 1. DIRECTORIES & FILE LIST ────────────────────────────────────────────
if ~isfolder(cfg.outDir), mkdir(cfg.outDir); end
figDir = fullfile(cfg.outDir, 'figures');
if ~isfolder(figDir), mkdir(figDir); end

% Exclude template / output files
skipPat = {'wear_log','template','results','success','anova','effect','analysis'};
all_csv = dir(fullfile(cfg.dataDir,'*.csv'));
csvFiles = all_csv(~cellfun(@(n) any(contains(lower(n),skipPat)), {all_csv.name}));

if isempty(csvFiles)
    error('No data CSV files found in: %s', cfg.dataDir);
end
fprintf('Found %d CSV files to process.\n\n', numel(csvFiles));

%% ── 2. IMPORT, SEGMENT, COMPUTE METRICS ──────────────────────────────────
allSeg  = table();
rawData = struct();   % keyed by valid MATLAB fieldname per file

for i = 1:numel(csvFiles)
    fname    = string(csvFiles(i).name);
    fullPath = fullfile(csvFiles(i).folder, csvFiles(i).name);
    fprintf('[%d/%d] %s\n', i, numel(csvFiles), fname);

    data     = brk_import_bruker_csv(fullPath, cfg);
    T        = data.all;

    segments = brk_segment_by_thresholds(T, cfg);
    fprintf('       Detected %d braking segments.\n', numel(segments));

    cond = brk_infer_condition(fname, cfg);
    fprintf('       Condition: texture="%s"  env="%s"\n', cond.texture, cond.environment);

    R             = brk_compute_metrics(T, segments, cfg);
    R.file        = repmat(fname,                     height(R), 1);
    R.texture     = repmat(string(cond.texture),     height(R), 1);
    R.environment = repmat(string(cond.environment), height(R), 1);

    allSeg = [allSeg; R]; %#ok<AGROW>

    key = matlab.lang.makeValidName(erase(fname,'.csv'));
    rawData.(key).T        = T;
    rawData.(key).segments = segments;
    rawData.(key).cond     = cond;
    rawData.(key).fname    = fname;
end

% Optional wear log
if strlength(cfg.wearLogPath) > 0 && isfile(cfg.wearLogPath)
    allSeg = brk_merge_wear_log(allSeg, cfg);
    fprintf('\nWear log merged.\n');
end

%% ── 3. PER-CONDITION SUMMARY ──────────────────────────────────────────────
perCond = brk_summarise_conditions(allSeg, cfg);
fprintf('\n=== Per-Condition Summary ===\n');
disp(perCond);

%% ── 4. SUCCESS CRITERIA ───────────────────────────────────────────────────
criteria = brk_evaluate_success_criteria(perCond, cfg);

% Optional extra criterion for dashboard: whether ΔT improved vs flat baseline
if ismember('dT_max_mean', perCond.Properties.VariableNames)
    criteria.dT_max_mean = NaN(height(criteria),1);
    criteria.dT_improved = false(height(criteria),1);

    for e = unique(criteria.environment, 'stable')'
        idxEnv  = criteria.environment == e;
        idxBase = idxEnv & criteria.texture == "flat";
        if ~any(idxBase), continue; end

        dTbase = perCond.dT_max_mean(find(idxBase,1,'first'));

        for i = find(idxEnv)'
            idxThis = perCond.texture == criteria.texture(i) & perCond.environment == criteria.environment(i);
            if any(idxThis)
                criteria.dT_max_mean(i) = perCond.dT_max_mean(find(idxThis,1,'first'));
                criteria.dT_improved(i) = criteria.dT_max_mean(i) < dTbase;
            end
        end
    end
else
    criteria.dT_max_mean = NaN(height(criteria),1);
    criteria.dT_improved = false(height(criteria),1);
end

fprintf('\n=== Success Criteria (Chapter 7.9) ===\n');
disp(criteria);

%% ── 5. TWO-WAY ANOVA ──────────────────────────────────────────────────────
fprintf('\n=== Two-Way ANOVA: Texture × Environment ===\n');
anova_mu = []; anova_dT = []; effect_mu = []; effect_dT = [];
try
    if ismember('mu_mean', allSeg.Properties.VariableNames)
        [anova_mu, effect_mu] = brk_two_way_anova(allSeg, 'mu_mean', cfg);
        fprintf('  Response: mu_mean\n'); disp(anova_mu); disp(effect_mu);
        writetable(anova_mu,  fullfile(cfg.outDir,'anova_mu_mean.csv'));
        writetable(effect_mu, fullfile(cfg.outDir,'effectsize_mu_mean.csv'));
    end
    if ismember('dT_max', allSeg.Properties.VariableNames)
        [anova_dT, effect_dT] = brk_two_way_anova(allSeg, 'dT_max', cfg);
        fprintf('  Response: dT_max\n'); disp(anova_dT); disp(effect_dT);
        writetable(anova_dT,  fullfile(cfg.outDir,'anova_dT_max.csv'));
        writetable(effect_dT, fullfile(cfg.outDir,'effectsize_dT_max.csv'));
    end
catch ME
    warning('ANOVA skipped: %s', ME.message);
end

%% ── 6. EXPORT TABLES ──────────────────────────────────────────────────────
writetable(allSeg,   fullfile(cfg.outDir,'results_perSegment.csv'));
writetable(perCond,  fullfile(cfg.outDir,'results_perCondition.csv'));
writetable(criteria, fullfile(cfg.outDir,'success_criteria.csv'));
fprintf('\nResult tables saved to: %s\n', cfg.outDir);

%% ── 7. FIGURE CONSTANTS ───────────────────────────────────────────────────
CLR.dry     = [0.85 0.33 0.10];   % burnt orange
CLR.wet     = [0.13 0.47 0.71];   % steel blue
TEX_KEYS    = ["flat",           "one-hole",  "two-hole" ];
TEX_LABELS  = ["Flat (Baseline)","One-Hole",  "Two-Hole" ];
TEX_COLORS  = [[0.40 0.40 0.40];  % grey
               [0.18 0.63 0.36];  % green
               [0.56 0.12 0.82]]; % purple
ENV_KEYS    = ["dry","wet"];
LS_REP      = {'-','--',':'};
ALPHA_REP   = [1.0, 0.75, 0.55];
BW          = 0.32;   % bar half-width for grouped charts

%% ── FIG 1: μ vs time, 3×2 grid ────────────────────────────────────────────
fig1 = figure('Color','w','Position',[50 50 1380 860]);
tl   = tiledlayout(fig1,3,2,'TileSpacing','compact','Padding','compact');
title(tl,'\mu vs Time – All Conditions (3 Repetitions Overlaid)','FontSize',13,'FontWeight','bold');
for ti=1:3
    for ei=1:2
        ax=nexttile(tl); hold(ax,'on'); grid(ax,'on'); box(ax,'on'); ax.GridAlpha=0.25;
        col = CLR.(char(ENV_KEYS(ei)));
        fn_list = fieldnames(rawData);
        for fi=1:numel(fn_list)
            d=rawData.(fn_list{fi});
            if string(d.cond.texture)==TEX_KEYS(ti) && string(d.cond.environment)==ENV_KEYS(ei)
                T_=d.T; segs=d.segments;
                for si=1:numel(segs)
                    idx=segs(si).idxSteady; if isempty(idx),continue; end
                    t_=T_.time_global_s(idx)-T_.time_global_s(idx(1));
                    mu_=T_.mu(idx);
                    dt_=median(diff(t_),'omitnan'); if isnan(dt_)||dt_<=0,dt_=0.01;end
                    win=max(1,round(cfg.movingMeanWindow_s/dt_));
                    muS=movmean(mu_,win,'omitnan');
                    plot(ax,t_,muS,LS_REP{si},'Color',[col,ALPHA_REP(si)],'LineWidth',1.4,'DisplayName',sprintf('Rep %d',si));
                end
                break;
            end
        end
        title(ax,sprintf('%s — %s',TEX_LABELS(ti),upper(char(ENV_KEYS(ei)))),'FontSize',9.5,'FontWeight','bold');
        xlabel(ax,'Time in braking event (s)'); ylabel(ax,'\mu');
        legend(ax,'Location','best','FontSize',7.5);
    end
end
brk_localSave(fig1,figDir,'Fig01_mu_timeseries',cfg);

%% ── FIG 2: Torque vs time + RPM secondary axis ────────────────────────────
fig2 = figure('Color','w','Position',[60 50 1380 860]);
tl   = tiledlayout(fig2,3,2,'TileSpacing','compact','Padding','compact');
title(tl,'Torque vs Time with Rotational Speed Overlay','FontSize',13,'FontWeight','bold');
for ti=1:3
    for ei=1:2
        ax=nexttile(tl); grid(ax,'on'); box(ax,'on'); ax.GridAlpha=0.25;
        col=CLR.(char(ENV_KEYS(ei)));
        fn_list=fieldnames(rawData);
        for fi=1:numel(fn_list)
            d=rawData.(fn_list{fi});
            if string(d.cond.texture)==TEX_KEYS(ti) && string(d.cond.environment)==ENV_KEYS(ei)
                T_=d.T; segs=d.segments;
                for si=1:numel(segs)
                    idx=segs(si).idxSteady; if isempty(idx),continue;end
                    t_=T_.time_global_s(idx)-T_.time_global_s(idx(1));
                    torq=T_.torque_Nm(idx); rpm_=T_.rpm(idx);
                    dt_=median(diff(t_),'omitnan'); if isnan(dt_)||dt_<=0,dt_=0.01;end
                    win=max(1,round(cfg.movingMeanWindow_s/dt_));
                    tS=movmean(torq,win,'omitnan'); rS=movmean(rpm_,win,'omitnan');
                    yyaxis(ax,'left'); hold(ax,'on');
                    plot(ax,t_,abs(tS),LS_REP{si},'Color',[col,ALPHA_REP(si)],'LineWidth',1.4,'DisplayName',sprintf('Rep %d',si));
                    yyaxis(ax,'right'); hold(ax,'on');
                    plot(ax,t_,rS,LS_REP{si},'Color',[0.55 0.55 0.55 ALPHA_REP(si)*0.7],'LineWidth',0.9,'HandleVisibility','off');
                end
                break;
            end
        end
        yyaxis(ax,'left');  ylabel(ax,'|Torque| (N·m)','Color','k');
        yyaxis(ax,'right'); ylabel(ax,'Speed (RPM)','Color',[0.5 0.5 0.5]);
        ax.YAxis(1).Color='k'; ax.YAxis(2).Color=[0.5 0.5 0.5];
        title(ax,sprintf('%s — %s',TEX_LABELS(ti),upper(char(ENV_KEYS(ei)))),'FontSize',9.5,'FontWeight','bold');
        xlabel(ax,'Time (s)');
        yyaxis(ax,'left'); legend(ax,'Location','best','FontSize',7);
    end
end
brk_localSave(fig2,figDir,'Fig02_torque_rpm_timeseries',cfg);

%% ── FIG 3: Temperature evolution (Tpad & Tdsk) ────────────────────────────
fig3 = figure('Color','w','Position',[70 50 1380 860]);
tl   = tiledlayout(fig3,3,2,'TileSpacing','compact','Padding','compact');
title(tl,'Temperature Rise ΔT vs Time – Pad and Disc Channels','FontSize',13,'FontWeight','bold');
for ti=1:3
    for ei=1:2
        ax=nexttile(tl); hold(ax,'on'); grid(ax,'on'); box(ax,'on'); ax.GridAlpha=0.25;
        col=CLR.(char(ENV_KEYS(ei)));
        fn_list=fieldnames(rawData);
        for fi=1:numel(fn_list)
            d=rawData.(fn_list{fi});
            if string(d.cond.texture)==TEX_KEYS(ti) && string(d.cond.environment)==ENV_KEYS(ei)
                T_=d.T; segs=d.segments;
                hasPad=ismember('Tpad_C',T_.Properties.VariableNames);
                hasDsk=ismember('Tdsk_C',T_.Properties.VariableNames);
                for si=1:numel(segs)
                    idx=segs(si).idxAll; if isempty(idx),continue;end
                    t_=T_.time_global_s(idx)-T_.time_global_s(idx(1));
                    if hasPad
                        Tp=T_.Tpad_C(idx); T0p=median(Tp(t_<0.3),'omitnan');
                        plot(ax,t_,Tp-T0p,LS_REP{si},'Color',[col,ALPHA_REP(si)],'LineWidth',1.3,'DisplayName',sprintf('Pad Rep%d',si));
                    end
                    if hasDsk
                        Td=T_.Tdsk_C(idx); T0d=median(Td(t_<0.3),'omitnan');
                        plot(ax,t_,Td-T0d,LS_REP{si},'Color',[col*0.55+0.45,ALPHA_REP(si)*0.7], ...
                            'LineWidth',0.9,'LineStyle','-.','DisplayName',sprintf('Disc Rep%d',si));
                    end
                end
                break;
            end
        end
        yline(ax,0,'k:','LineWidth',0.7,'HandleVisibility','off');
        title(ax,sprintf('%s — %s',TEX_LABELS(ti),upper(char(ENV_KEYS(ei)))),'FontSize',9.5,'FontWeight','bold');
        xlabel(ax,'Time (s)'); ylabel(ax,'\DeltaT (°C)');
        legend(ax,'Location','best','FontSize',6.5);
    end
end
brk_localSave(fig3,figDir,'Fig03_temperature_traces',cfg);

%% ── FIG 4: Mean μ grouped bar chart ──────────────────────────────────────
[mu_d,mu_de,mu_w,mu_we]=deal(NaN(3,1));
for ti=1:3
    id=perCond.texture==TEX_KEYS(ti)&perCond.environment=="dry";
    iw=perCond.texture==TEX_KEYS(ti)&perCond.environment=="wet";
    if any(id),mu_d(ti)=perCond.mu_mean(id);mu_de(ti)=perCond.mu_sd(id);end
    if any(iw),mu_w(ti)=perCond.mu_mean(iw);mu_we(ti)=perCond.mu_sd(iw);end
end
fig4=figure('Color','w','Position',[100 100 820 500]);
ax4=axes(fig4); hold(ax4,'on'); box(ax4,'on'); grid(ax4,'on'); ax4.GridAlpha=0.25;
bar(ax4,(1:3)-BW/2-0.02,mu_d,BW,'FaceColor',CLR.dry,'EdgeColor','none','FaceAlpha',0.88,'DisplayName','Dry');
bar(ax4,(1:3)+BW/2+0.02,mu_w,BW,'FaceColor',CLR.wet,'EdgeColor','none','FaceAlpha',0.88,'DisplayName','Wet');
errorbar(ax4,(1:3)-BW/2-0.02,mu_d,mu_de,'.k','LineWidth',1.5,'CapSize',6,'HandleVisibility','off');
errorbar(ax4,(1:3)+BW/2+0.02,mu_w,mu_we,'.k','LineWidth',1.5,'CapSize',6,'HandleVisibility','off');
for ti=1:3
    if ~isnan(mu_d(ti))
        text(ax4,ti-BW/2-0.02,mu_d(ti)+mu_de(ti)+0.025,sprintf('%.3f',mu_d(ti)), ...
            'HorizontalAlignment','center','FontSize',9,'FontWeight','bold','Color',CLR.dry*0.65);
    end
    if ~isnan(mu_w(ti))
        text(ax4,ti+BW/2+0.02,mu_w(ti)+mu_we(ti)+0.025,sprintf('%.3f',mu_w(ti)), ...
            'HorizontalAlignment','center','FontSize',9,'FontWeight','bold','Color',CLR.wet*0.65);
    end
end
set(ax4,'XTick',1:3,'XTickLabel',TEX_LABELS,'FontSize',10.5);
ylabel(ax4,'Mean Friction Coefficient (\mu)','FontSize',11);
title(ax4,'Mean Friction Coefficient by Texture and Environment','FontSize',12,'FontWeight','bold');
subtitle(ax4,'Error bars = ±1 SD across n=3 repetitions','FontSize',9,'Color',[0.4 0.4 0.4]);
legend(ax4,'Location','northwest','FontSize',10);
brk_localSave(fig4,figDir,'Fig04_mu_summary_bar',cfg);

%% ── FIG 5: ΔT grouped bar chart ──────────────────────────────────────────
dT_fld='dT_max_mean'; dT_sd_fld='dT_max_sd';
if ~ismember(dT_fld,perCond.Properties.VariableNames)
    dT_fld='dT_p95_mean'; dT_sd_fld='dT_p95_sd';
end
[dT_d,dT_de,dT_w,dT_we]=deal(NaN(3,1));
if ismember(dT_fld,perCond.Properties.VariableNames)
    for ti=1:3
        id=perCond.texture==TEX_KEYS(ti)&perCond.environment=="dry";
        iw=perCond.texture==TEX_KEYS(ti)&perCond.environment=="wet";
        if any(id),dT_d(ti)=perCond.(dT_fld)(id);dT_de(ti)=perCond.(dT_sd_fld)(id);end
        if any(iw),dT_w(ti)=perCond.(dT_fld)(iw);dT_we(ti)=perCond.(dT_sd_fld)(iw);end
    end
end
fig5=figure('Color','w','Position',[120 100 820 500]);
ax5=axes(fig5); hold(ax5,'on'); box(ax5,'on'); grid(ax5,'on'); ax5.GridAlpha=0.25;
bar(ax5,(1:3)-BW/2-0.02,dT_d,BW,'FaceColor',CLR.dry,'EdgeColor','none','FaceAlpha',0.88,'DisplayName','Dry');
bar(ax5,(1:3)+BW/2+0.02,dT_w,BW,'FaceColor',CLR.wet,'EdgeColor','none','FaceAlpha',0.88,'DisplayName','Wet');
errorbar(ax5,(1:3)-BW/2-0.02,dT_d,dT_de,'.k','LineWidth',1.5,'CapSize',6,'HandleVisibility','off');
errorbar(ax5,(1:3)+BW/2+0.02,dT_w,dT_we,'.k','LineWidth',1.5,'CapSize',6,'HandleVisibility','off');
for ti=1:3
    for jj=1:2
        if jj==1
            v_=dT_d(ti); e_=dT_de(ti); xo=-BW/2-0.02; c_=CLR.dry;
        else
            v_=dT_w(ti); e_=dT_we(ti); xo=+BW/2+0.02; c_=CLR.wet;
        end
        if ~isnan(v_)
            text(ax5,ti+xo,max(v_,0)+max(e_,0)+0.25,sprintf('%.1f°C',v_), ...
                'HorizontalAlignment','center','FontSize',8.5,'FontWeight','bold','Color',c_*0.65);
        end
    end
end
set(ax5,'XTick',1:3,'XTickLabel',TEX_LABELS,'FontSize',10.5);
ylabel(ax5,'\DeltaT_{max} = T_{max} - T_0 (°C)','FontSize',11);
title(ax5,'Temperature Rise by Texture and Environment','FontSize',12,'FontWeight','bold');
subtitle(ax5,'T_0 = median temperature at onset of braking  |  Error bars = ±1 SD','FontSize',9,'Color',[0.4 0.4 0.4]);
legend(ax5,'Location','northwest','FontSize',10);
yline(ax5,0,'HandleVisibility','off');
brk_localSave(fig5,figDir,'Fig05_dT_summary_bar',cfg);

%% ── FIG 6: Dry vs Wet paired scatter ─────────────────────────────────────
fig6=figure('Color','w','Position',[140 100 820 460]);
tl6=tiledlayout(fig6,1,2,'TileSpacing','compact','Padding','compact');
title(tl6,'Dry vs Wet Comparison – Individual Repetitions & Condition Means','FontSize',12,'FontWeight','bold');
mets6={'mu_mean','dT_max'};
ylb6 ={'\mu (friction coefficient)','\DeltaT_{max} (°C)'};
ttl6 ={'Friction Coefficient','Temperature Rise'};
for mi=1:2
    ax=nexttile(tl6); hold(ax,'on'); box(ax,'on'); grid(ax,'on'); ax.GridAlpha=0.25;
    if ~ismember(mets6{mi},allSeg.Properties.VariableNames),continue;end
    for ti=1:3
        c_=TEX_COLORS(ti,:);
        yd=allSeg.(mets6{mi})(allSeg.texture==TEX_KEYS(ti)&allSeg.environment=="dry");
        yw=allSeg.(mets6{mi})(allSeg.texture==TEX_KEYS(ti)&allSeg.environment=="wet");
        n_=min(numel(yd),numel(yw)); if n_==0,continue;end
        for r=1:n_
            plot(ax,[1 2],[yd(r) yw(r)],'-','Color',[c_,0.25],'LineWidth',0.8);
        end
        plot(ax,1,mean(yd,'omitnan'),'o','MarkerFaceColor',c_,'MarkerEdgeColor','k','MarkerSize',10,'LineWidth',1,'DisplayName',TEX_LABELS(ti));
        plot(ax,2,mean(yw,'omitnan'),'o','MarkerFaceColor',c_,'MarkerEdgeColor','k','MarkerSize',10,'LineWidth',1,'HandleVisibility','off');
        plot(ax,[1 2],[mean(yd,'omitnan') mean(yw,'omitnan')],'-','Color',c_,'LineWidth',2,'HandleVisibility','off');
    end
    set(ax,'XTick',[1 2],'XTickLabel',{'Dry','Wet'},'FontSize',11,'XLim',[0.6 2.4]);
    ylabel(ax,ylb6{mi},'FontSize',10); title(ax,ttl6{mi},'FontSize',11,'FontWeight','bold');
    if mi==1,legend(ax,'Location','best','FontSize',9);end
end
brk_localSave(fig6,figDir,'Fig06_dry_wet_paired',cfg);

%% ── FIG 7: Repeatability – μ per repetition ──────────────────────────────
fig7=figure('Color','w','Position',[50 50 1100 730]);
tl7=tiledlayout(fig7,2,3,'TileSpacing','compact','Padding','compact');
title(tl7,'\mu per Repetition – Repeatability Assessment','FontSize',12,'FontWeight','bold');
for ei=1:2
    for ti=1:3
        ax=nexttile(tl7); hold(ax,'on'); grid(ax,'on'); box(ax,'on'); ax.GridAlpha=0.25;
        col=CLR.(char(ENV_KEYS(ei)));
        sub=allSeg(allSeg.texture==TEX_KEYS(ti)&allSeg.environment==ENV_KEYS(ei),:);
        if ~isempty(sub)
            mu_v=sub.mu_mean; mu_e=sub.mu_std;
            errorbar(ax,1:height(sub),mu_v,mu_e,'o-','Color',col,'MarkerFaceColor',col,'MarkerSize',8,'LineWidth',1.5,'CapSize',7);
            mu_bar=mean(mu_v,'omitnan'); cv_=100*std(mu_v,'omitnan')/mu_bar;
            yline(ax,mu_bar,'--','Color',col*0.65,'LineWidth',1,'Label',sprintf('\\mu=%.3f',mu_bar),'LabelHorizontalAlignment','left','FontSize',8);
            text(ax,0.97,0.07,sprintf('CV=%.1f%%',cv_), ...
                'Units','norm','HorizontalAlignment','right','FontSize',9,'Color',col*0.65,'FontWeight','bold');
        end
        set(ax,'XTick',1:3,'XLim',[0.4 3.6],'FontSize',9);
        xlabel(ax,'Repetition #'); ylabel(ax,'\mu ± within-rep SD');
        title(ax,sprintf('%s | %s',TEX_LABELS(ti),upper(char(ENV_KEYS(ei)))),'FontSize',9.5,'FontWeight','bold');
    end
end
brk_localSave(fig7,figDir,'Fig07_repeatability',cfg);

%% ── FIG 8: μ vs sliding distance ─────────────────────────────────────────
fig8=figure('Color','w','Position',[80 50 1380 860]);
tl8=tiledlayout(fig8,3,2,'TileSpacing','compact','Padding','compact');
title(tl8,'\mu vs Cumulative Sliding Distance','FontSize',13,'FontWeight','bold');
for ti=1:3
    for ei=1:2
        ax=nexttile(tl8); hold(ax,'on'); grid(ax,'on'); box(ax,'on'); ax.GridAlpha=0.25;
        col=CLR.(char(ENV_KEYS(ei)));
        fn_list=fieldnames(rawData);
        for fi=1:numel(fn_list)
            d=rawData.(fn_list{fi});
            if string(d.cond.texture)==TEX_KEYS(ti)&&string(d.cond.environment)==ENV_KEYS(ei)
                T_=d.T; segs=d.segments;
                for si=1:numel(segs)
                    idx=segs(si).idxSteady; if isempty(idx),continue;end
                    t_=T_.time_global_s(idx);
                    r_=median(T_.radius_m(idx),'omitnan'); if isnan(r_),r_=cfg.trackRadius_m;end
                    s_=cumtrapz(t_-t_(1),2*pi*r_*(T_.rpm(idx)/60));
                    mu_=T_.mu(idx);
                    dt_=median(diff(t_),'omitnan'); if isnan(dt_)||dt_<=0,dt_=0.01;end
                    win=max(1,round(cfg.movingMeanWindow_s/dt_));
                    muS=movmean(mu_,win,'omitnan');
                    plot(ax,s_,muS,LS_REP{si},'Color',[col,ALPHA_REP(si)],'LineWidth',1.3,'DisplayName',sprintf('Rep %d',si));
                end
                break;
            end
        end
        title(ax,sprintf('%s — %s',TEX_LABELS(ti),upper(char(ENV_KEYS(ei)))),'FontSize',9.5,'FontWeight','bold');
        xlabel(ax,'Sliding Distance (m)'); ylabel(ax,'\mu');
        legend(ax,'Location','best','FontSize',7);
    end
end
brk_localSave(fig8,figDir,'Fig08_mu_vs_distance',cfg);

%% ── FIG 9: Dry vs Wet mean±SD band overlay (per texture) ─────────────────
fig9=figure('Color','w','Position',[100 50 1050 800]);
tl9=tiledlayout(fig9,3,1,'TileSpacing','compact','Padding','compact');
title(tl9,'Dry vs Wet \mu – Mean ± 1SD Band (n=3 Repetitions)','FontSize',12,'FontWeight','bold');
for ti=1:3
    ax=nexttile(tl9); hold(ax,'on'); box(ax,'on'); grid(ax,'on'); ax.GridAlpha=0.25;
    for ei=1:2
        col=CLR.(char(ENV_KEYS(ei)));
        all_mu={};
        fn_list=fieldnames(rawData);
        for fi=1:numel(fn_list)
            d=rawData.(fn_list{fi});
            if string(d.cond.texture)==TEX_KEYS(ti)&&string(d.cond.environment)==ENV_KEYS(ei)
                T_=d.T; segs=d.segments;
                for si=1:numel(segs)
                    idx=segs(si).idxSteady; if isempty(idx),continue;end
                    t_=T_.time_global_s(idx)-T_.time_global_s(idx(1));
                    mu_=T_.mu(idx);
                    dt_=median(diff(t_),'omitnan'); if isnan(dt_)||dt_<=0,dt_=0.01;end
                    win=max(1,round(cfg.movingMeanWindow_s/dt_));
                    muS=movmean(mu_,win,'omitnan');
                    all_mu{end+1}=struct('t',t_,'mu',muS); %#ok<SAGROW>
                end
                break;
            end
        end
        if isempty(all_mu),continue;end
        t_max=min(cellfun(@(x)x.t(end),all_mu));
        t_g=(0:0.01:t_max)';
        mu_mat=NaN(numel(t_g),numel(all_mu));
        for r=1:numel(all_mu)
            mu_mat(:,r)=interp1(all_mu{r}.t,all_mu{r}.mu,t_g,'linear','extrap');
        end
        mu_avg=mean(mu_mat,2,'omitnan'); mu_sd=std(mu_mat,0,2,'omitnan');
        fill(ax,[t_g;flipud(t_g)],[mu_avg+mu_sd;flipud(mu_avg-mu_sd)],col, ...
            'FaceAlpha',0.15,'EdgeColor','none','HandleVisibility','off');
        plot(ax,t_g,mu_avg,'-','Color',col,'LineWidth',2,'DisplayName',sprintf('%s (mean ± SD)',upper(char(ENV_KEYS(ei)))));
    end
    title(ax,TEX_LABELS(ti),'FontSize',11,'FontWeight','bold');
    xlabel(ax,'Time (s)'); ylabel(ax,'\mu');
    legend(ax,'Location','best','FontSize',10);
end
brk_localSave(fig9,figDir,'Fig09_dry_wet_mean_sd_bands',cfg);

%% ── FIG 10: Success criteria dashboard ───────────────────────────────────
fig10 = brk_localSuccessDash(criteria, TEX_LABELS);
brk_localSave(fig10,figDir,'Fig10_success_criteria_dashboard',cfg);

fprintf('\n=== Analysis complete. All outputs in: %s ===\n', cfg.outDir);

%% =========================================================================
%%  LOCAL HELPERS
%% =========================================================================

function brk_localSave(fig, outDir, name, cfg)
    if ~isfolder(outDir), mkdir(outDir); end
    for k=1:numel(cfg.exportFormats)
        fmt=lower(string(cfg.exportFormats{k}));
        p=fullfile(outDir, name+"."+fmt);
        try
            if fmt=="png"
                exportgraphics(fig,p,'Resolution',cfg.exportDPI);
            elseif fmt=="pdf"
                exportgraphics(fig,p,'ContentType','vector');
            else
                saveas(fig,p);
            end
        catch ME
            warning('Save failed for %s: %s',name,ME.message);
        end
    end
    fprintf('  Saved: %s\n',name);
    close(fig);
end

function fig = brk_localSuccessDash(C, texLabels)
    fig=figure('Color','w','Position',[400 100 1020 620]);
    ax=axes(fig,'Visible','off');
    xlim(ax,[0 1]); ylim(ax,[0 1]);

    ann=@(pos,str,varargin) annotation(fig,'textbox',pos,'String',str, ...
        'HorizontalAlignment','center','VerticalAlignment','middle', ...
        'EdgeColor','k','LineWidth',0.5,'Interpreter','tex',varargin{:});

    text(ax,0.5,0.975,'Success Criteria Evaluation – Chapter 7.9', ...
        'Units','norm','HorizontalAlignment','center','FontSize',14,'FontWeight','bold');

    text(ax,0.5,0.930,'Criterion 1: |\Delta\mu| \leq5% vs flat baseline  |  Criterion 2: \DeltaT_{max} reduced vs flat', ...
        'Units','norm','HorizontalAlignment','center','FontSize',9.5,'Color',[0.35 0.35 0.35]);

    hdrC  = [0.18 0.40 0.65];
    colX  = [0.02 0.18 0.28 0.35 0.43 0.51 0.61 0.72 0.83 1.00];
    rowH  = 0.095; yHdr = 0.885;
    hdrs  = {'Texture','Env','n','\mu mean','\mu SD','\Delta\mu (%)', ...
             '\mu Pass \leq5%','\DeltaT_{max} (°C)','\DeltaT improved?'};

    for c=1:numel(hdrs)
        ann([colX(c) yHdr colX(c+1)-colX(c) rowH],hdrs{c}, ...
            'FontWeight','bold','FontSize',8.5,'BackgroundColor',hdrC,'Color','w');
    end

    bg1=[1 1 1]; bg2=[0.95 0.95 0.95];
    pC =[0.76 0.95 0.78]; fC=[0.98 0.78 0.76];

    for r=1:height(C)
        yP=yHdr-r*rowH;
        bg=bg1; if mod(r,2)==0, bg=bg2; end
        mp=C.mu_pass_5pct(r);
        di=C.dT_improved(r);

        dT_str='N/A';
        if ismember('dT_max_mean',C.Properties.VariableNames) && ~isnan(C.dT_max_mean(r))
            dT_str=sprintf('%.2f',C.dT_max_mean(r));
        end

        vals={char(C.texture(r)), char(C.environment(r)), num2str(C.n(r)), ...
              sprintf('%.3f',C.mu_mean(r)), sprintf('%.3f',C.mu_sd(r)), ...
              sprintf('%.1f%%',C.mu_diff_pct_vs_flat(r)), ...
              brk_pf(mp), dT_str, brk_pf(di)};

        for c=1:numel(hdrs)
            if c==7
                bgC=pC; if ~mp, bgC=fC; end
            elseif c==9
                bgC=pC; if ~di, bgC=fC; end
            else
                bgC=bg;
            end
            ann([colX(c) yP colX(c+1)-colX(c) rowH],vals{c}, ...
                'FontSize',8.5,'BackgroundColor',bgC,'EdgeColor',[0.7 0.7 0.7]);
        end
    end

    text(ax,0.02,0.025,'Green = criterion met   Red = criterion not met', ...
        'Units','norm','FontSize',9,'Color',[0.3 0.3 0.3]);
end

function s = brk_pf(v)
    if v
        s=sprintf('%s PASS',char(10003));
    else
        s=sprintf('%s FAIL',char(10007));
    end
end