function data = brk_import_bruker_csv(filePath, cfg)
% brk_import_bruker_csv  Robust importer for Bruker UMT TriboLab CSV exports.
%
% Fully compatible with MATLAB R2018b and newer (uses only char arrays,
% no string-class name-value arguments in built-in functions).
%
% Reads multi-step Bruker CSV files where each step block contains:
%   - metadata lines (Step No., Radius, Velocity, etc.)
%   - a header line  (T,Fz,Tz,Tpad,Tdsk,Z,V2,COF-T)
%   - a units line   (sec,N,N·m,...)
%   - numeric data rows
%
% Output:  data.all  — table with columns:
%   time_s, time_global_s, load_N, torque_Nm, tangential_N, rpm,
%   Tpad_C, Tdsk_C, radius_m, mu, v_mps, s_m, s_global_m, stepNo

% ── Read all lines from file ──────────────────────────────────────────────
lines = local_readlines(char(filePath));
if isempty(lines)
    error('brk_import_bruker_csv: could not read file: %s', char(filePath));
end

nLines = numel(lines);

% ── Find all header lines (start with a letter, contain commas, not numeric)
hdrIdx = [];
for i = 1:nLines
    L = strtrim(lines{i});
    if isempty(L),                     continue; end
    if local_isnumericline(L),         continue; end
    if ~(L(1) >= 'A' && L(1) <= 'z'), continue; end
    if sum(L == ',') >= 2
        hdrIdx(end+1) = i; %#ok<AGROW>
    end
end

if isempty(hdrIdx)
    error('brk_import_bruker_csv: no data headers found in %s', char(filePath));
end

Tall      = [];
tOffset   = 0;
colNames  = {};   % will be set from first valid block

for b = 1:numel(hdrIdx)
    h     = hdrIdx(b);
    hLine = strtrim(lines{h});

    % ── Parse column names ────────────────────────────────────────────────
    rawCols = strsplit(hLine, ',');
    rawCols = strtrim(rawCols);
    rawCols = rawCols(~cellfun('isempty', rawCols));
    nC      = numel(rawCols);
    if nC < 3, continue; end

    % ── Find start of numeric data (skip units line etc.) ─────────────────
    dStart = h + 1;
    while dStart <= nLines && ~local_isnumericline(strtrim(lines{dStart}))
        dStart = dStart + 1;
    end
    if dStart > nLines, continue; end

    % ── Find end of numeric data block ────────────────────────────────────
    dEnd = dStart;
    while dEnd < nLines && local_isnumericline(strtrim(lines{dEnd + 1}))
        dEnd = dEnd + 1;
    end
    nRows = dEnd - dStart + 1;
    if nRows < 2, continue; end

    % ── Parse numeric block ───────────────────────────────────────────────
    X = NaN(nRows, nC);
    for r = 1:nRows
        row_str = strtrim(lines{dStart + r - 1});
        parts   = strsplit(row_str, ',');
        for c = 1:min(numel(parts), nC)
            val = strtrim(parts{c});
            if ~isempty(val)
                v = str2double(val);
                if ~isnan(v)
                    X(r, c) = v;
                end
            end
        end
    end

    % ── Get step metadata from lines above this header ────────────────────
    [stepNo, radius_m, setRPM, setForce_N] = local_parse_meta(lines, h);

    % ── Map columns to standard names ─────────────────────────────────────
    cols = local_mapcols(rawCols);   % struct with field indices

    % ── Extract channels ──────────────────────────────────────────────────
    time_s       = local_getcol(X, cols.time);
    load_N       = local_getcol(X, cols.load);
    torque_Nm    = local_getcol(X, cols.torque);
    tangential_N = local_getcol(X, cols.ft);
    rpm          = local_getcol(X, cols.rpm);
    Tpad_C       = local_getcol(X, cols.tpad);
    Tdsk_C       = local_getcol(X, cols.tdsk);
    cof_raw      = local_getcol(X, cols.cof);

    if all(isnan(time_s)), continue; end   % skip if no time

    % Load: Bruker stores compressive force as negative
    load_N = abs(load_N);

    % Radius: prefer config override, then metadata, then NaN
    if isfield(cfg, 'trackRadius_m') && ~isnan(cfg.trackRadius_m)
        r_m = cfg.trackRadius_m;
    elseif ~isnan(radius_m)
        r_m = radius_m;
    else
        r_m = NaN;
    end

    % ── Friction coefficient ──────────────────────────────────────────────
    mu = NaN(nRows, 1);
    if ~all(isnan(cof_raw))
        mu  = cof_raw;
        med = nanmedian(abs(mu));
        if med > cfg.cofScaleIfMedianAbove
            mu = mu / 1000;   % Bruker stores COF × 1000 in some versions
        end
    elseif ~all(isnan(tangential_N)) && any(load_N > 0)
        mu = abs(tangential_N) ./ load_N;
    elseif ~isnan(r_m) && ~all(isnan(torque_Nm)) && any(load_N > 0)
        mu = abs(torque_Nm) ./ (r_m .* load_N);
    end

    % ── Velocity and distance ─────────────────────────────────────────────
    v_mps = NaN(nRows, 1);
    s_m   = NaN(nRows, 1);
    if ~isnan(r_m) && ~all(isnan(rpm))
        v_mps = 2 * pi * r_m .* (rpm / 60);
        s_m   = cumtrapz(time_s, v_mps);
    end

    % ── Make time monotonic ───────────────────────────────────────────────
    [time_s_u, ia] = unique(time_s, 'last');
    time_s       = time_s_u;
    load_N       = load_N(ia);
    torque_Nm    = torque_Nm(ia);
    tangential_N = tangential_N(ia);
    rpm          = rpm(ia);
    Tpad_C       = Tpad_C(ia);
    Tdsk_C       = Tdsk_C(ia);
    mu           = mu(ia);
    v_mps        = v_mps(ia);
    s_m          = s_m(ia);
    nRows        = numel(time_s);

    % ── Global time ───────────────────────────────────────────────────────
    dt_med = nanmedian(diff(time_s));
    if isnan(dt_med) || dt_med <= 0, dt_med = 0.01; end
    time_global_s = time_s + tOffset;
    tOffset       = time_global_s(end) + dt_med;

    stepNo_col = repmat(stepNo, nRows, 1);
    r_m_col    = repmat(r_m,   nRows, 1);

    % ── Assemble block matrix ─────────────────────────────────────────────
    block = [time_s, time_global_s, load_N, torque_Nm, tangential_N, ...
             rpm, Tpad_C, Tdsk_C, r_m_col, mu, v_mps, s_m, stepNo_col];

    if isempty(Tall)
        Tall = block;
    else
        Tall = [Tall; block]; %#ok<AGROW>
    end
end

if isempty(Tall)
    error('brk_import_bruker_csv: no valid data blocks parsed from %s', char(filePath));
end

% ── Build output table ────────────────────────────────────────────────────
T = array2table(Tall, 'VariableNames', ...
    {'time_s','time_global_s','load_N','torque_Nm','tangential_N', ...
     'rpm','Tpad_C','Tdsk_C','radius_m','mu','v_mps','s_m','stepNo'});

% Global sliding distance
if any(~isnan(T.v_mps))
    T.s_global_m = cumtrapz(T.time_global_s, T.v_mps);
else
    T.s_global_m = NaN(height(T), 1);
end

data          = struct();
data.filePath = char(filePath);
data.all      = T;

end


%% ── LOCAL HELPERS ────────────────────────────────────────────────────────

function lines = local_readlines(filePath)
% Try multiple encodings; return cell array of char strings
encs = {'UTF-8','ISO-8859-1','Windows-1252'};
lines = {};
for e = 1:numel(encs)
    fid = fopen(filePath, 'r', 'n', encs{e});
    if fid < 0, continue; end
    raw = {};
    tline = fgetl(fid);
    while ischar(tline)
        raw{end+1} = tline; %#ok<AGROW>
        tline = fgetl(fid);
    end
    fclose(fid);
    if ~isempty(raw)
        lines = raw;
        return;
    end
end
end


function tf = local_isnumericline(L)
% Returns true if L starts with a digit or sign character
tf = ~isempty(L) && (L(1) >= '0' && L(1) <= '9' || L(1) == '-' || L(1) == '+');
end


function [stepNo, radius_m, setRPM, setForce_N] = local_parse_meta(lines, hdrIdx)
stepNo    = NaN;
radius_m  = NaN;
setRPM    = NaN;
setForce_N = NaN;
win = max(1, hdrIdx - 80);
for i = hdrIdx : -1 : win
    L = lines{i};
    if isempty(L), continue; end
    if isnan(stepNo) && ~isempty(strfind(L, 'Step No.'))
        tok = regexp(L, 'Step No\.\s*(\d+)', 'tokens', 'once');
        if ~isempty(tok), stepNo = str2double(tok{1}); end
    end
    if isnan(radius_m) && ~isempty(strfind(L, 'Radius'))
        tok = regexp(L, 'Radius\s*=\s*([\-\d\.]+)', 'tokens', 'once');
        if ~isempty(tok), radius_m = str2double(tok{1}); end
    end
    if isnan(setRPM) && ~isempty(strfind(L, 'Velocity'))
        tok = regexp(L, 'Velocity\s*=\s*([\-\d\.]+)', 'tokens', 'once');
        if ~isempty(tok), setRPM = str2double(tok{1}); end
    end
    if isnan(setForce_N) && ~isempty(strfind(L, 'Set Force'))
        tok = regexp(L, 'Set Force\s*=\s*([\-\d\.]+)', 'tokens', 'once');
        if ~isempty(tok), setForce_N = str2double(tok{1}); end
    end
end
end


function cols = local_mapcols(rawCols)
% Map raw column names to standard indices
% Returns struct with field = index (0 = not found)
cols.time   = 0;
cols.load   = 0;
cols.torque = 0;
cols.ft     = 0;
cols.rpm    = 0;
cols.tpad   = 0;
cols.tdsk   = 0;
cols.cof    = 0;

time_cands   = {'T','Time','time','Seconds','sec'};
load_cands   = {'Fz','NormalLoad','Load','Fn','Fnormal','Normal Force'};
torque_cands = {'Tz','Torque','Mz','Moment'};
ft_cands     = {'Ft','FrictionForce','Friction Force','Fx','Fy'};
rpm_cands    = {'V2','RPM','Speed','Velocity','SpindleSpeed'};
tpad_cands   = {'Tpad','PadTemp','TempPad','Temperature1'};
tdsk_cands   = {'Tdsk','DiscTemp','TempDisc','Temperature2'};
cof_cands    = {'COF','COF_T','COF-T','mu','FrictionCoefficient'};

fields   = {'time',   'load',    'torque',    'ft',     'rpm',   'tpad',    'tdsk',    'cof'};
cand_set = {time_cands, load_cands, torque_cands, ft_cands, rpm_cands, tpad_cands, tdsk_cands, cof_cands};

for fi = 1:numel(fields)
    cands = cand_set{fi};
    for ci = 1:numel(cands)
        for ri = 1:numel(rawCols)
            if strcmpi(rawCols{ri}, cands{ci}) || ...
               ~isempty(strfind(lower(rawCols{ri}), lower(cands{ci})))
                cols.(fields{fi}) = ri;
                break;
            end
        end
        if cols.(fields{fi}) > 0, break; end
    end
end
end


function col = local_getcol(X, idx)
% Extract column by index, return NaN column if idx is 0
if idx > 0 && idx <= size(X, 2)
    col = X(:, idx);
else
    col = NaN(size(X, 1), 1);
end
end
