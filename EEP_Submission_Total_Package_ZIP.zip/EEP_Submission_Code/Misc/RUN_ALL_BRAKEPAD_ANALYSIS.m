%% RUN_ALL_BRAKEPAD_ANALYSIS.m
%  Single-click runner for the Brake Pad Tribology Analysis Pipeline
%
%  Author    : Nizam Ahmed (K22016355)
%  Supervisor: Dr Sorin-Cristian Vlădescu
%
%  SETUP INSTRUCTIONS:
%    1. Place ALL of the following in ONE folder:
%         - This file  (RUN_ALL_BRAKEPAD_ANALYSIS.m)
%         - run_brakepad_analysis.m
%         - All brk_*.m helper functions
%         - All six TEST*.csv data files
%         - (Optional) wear_log.csv  if mass measurements are available
%
%    2. Open this file in MATLAB and press F5 (Run), OR type:
%         run('RUN_ALL_BRAKEPAD_ANALYSIS')
%       in the Command Window.
%
%    3. All outputs (10 figures + CSV tables) are written to:
%         <this folder>/analysis_out/
%
%  NO PATH CHANGES NEEDED – the script auto-detects its own location.
%% =========================================================================

clear; clc; close all;

%% ── Auto-detect project folder ────────────────────────────────────────────
thisFile      = mfilename('fullpath');
projectFolder = fileparts(thisFile);
if isempty(projectFolder)          % fallback when run from Command Window
    projectFolder = pwd;
end
fprintf('Project folder: %s\n', projectFolder);
addpath(projectFolder);
cd(projectFolder);

%% ── Check required files are present ─────────────────────────────────────
helpers = {'run_brakepad_analysis.m','brk_default_config.m', ...
           'brk_import_bruker_csv.m','brk_infer_condition.m', ...
           'brk_segment_by_thresholds.m','brk_compute_metrics.m', ...
           'brk_summarise_conditions.m','brk_evaluate_success_criteria.m', ...
           'brk_two_way_anova.m','brk_plot_summary.m', ...
           'brk_plot_timeseries.m','brk_export_figure.m'};

csvs = {'TEST1-NOTEXTURE-DRY-REPETITION-25N-1000to800RPM.csv', ...
        'TEST1-NOTEXTURE-WET-REPETITION-25N-1000to800RPM.csv', ...
        'TEST2-ONE-HOLE-TEXTURE-DRY-REPETITION-25N-1000to800RPM.csv', ...
        'TEST2-ONE-HOLE-TEXTURE-WET-REPETITION-25N-1000to800RPM.csv', ...
        'TEST3-TWO-HOLE-TEXTURE-DRY-REPETITION-25N-1000to800RPM.csv', ...
        'TEST3-TWO-HOLE-TEXTURE-WET-REPETITION-25N-1000to800RPM.csv'};

all_files = [helpers, csvs];
missing   = all_files(~cellfun(@(f) isfile(fullfile(projectFolder,f)), all_files));

if ~isempty(missing)
    fprintf('\nMISSING FILES:\n');
    cellfun(@(f) fprintf('  - %s\n', f), missing);
    error('Please ensure all listed files are in:\n  %s', projectFolder);
end

fprintf('All required files found (%d helpers + %d CSV data files).\n', ...
    numel(helpers), numel(csvs));
fprintf('\nStarting analysis pipeline...\n\n');

%% ── Run the main pipeline ─────────────────────────────────────────────────
run_brakepad_analysis;
