function [anovaTbl, effectTbl] = brk_two_way_anova(allSeg, responseVar, cfg)
% brk_two_way_anova  Two-way ANOVA (texture x environment) + effect sizes.
%
% Uses anovan (unbalanced designs supported).
%
% Returns:
%   anovaTbl  (table: Term, SS, df, MS, F, p)
%   effectTbl (table: Term, partialEta2, cohensF)

resp = string(responseVar);
if ~ismember(resp, string(allSeg.Properties.VariableNames))
    error('Response not found: %s', char(resp));
end

T = allSeg;

% Exclude flagged segments
if ismember('isExcluded', T.Properties.VariableNames)
    T = T(~T.isExcluded, :);
end

y  = T.(char(resp));
g1 = categorical(T.texture);
g2 = categorical(T.environment);

valid = ~isnan(y) & ~isundefined(g1) & ~isundefined(g2);
y  = y(valid);
g1 = g1(valid);
g2 = g2(valid);

if numel(y) < 3
    error('Not enough valid observations for ANOVA on response: %s', char(resp));
end

% Use char-style args for best compatibility with anovan
[~, tbl] = anovan(y, {g1, g2}, ...
    'model', 'interaction', ...
    'varnames', {'Texture','Environment'}, ...
    'display', 'off');

% anovan returns a cell array table
% Usually rows are:
%   1 header
%   2 Texture
%   3 Environment
%   4 Interaction
%   5 Error
%   6 Total
%
% Columns are usually:
%   1 Source, 2 SS, 3 df, 4 MS, 5 F, 6 Prob>F

rawTerms = string(tbl(2:end,1));
nRows = numel(rawTerms);

SS   = NaN(nRows,1);
df   = NaN(nRows,1);
MS   = NaN(nRows,1);
Fval = NaN(nRows,1);
pval = NaN(nRows,1);

for i = 1:nRows
    if size(tbl,2) >= 2 && isnumeric(tbl{i+1,2})
        SS(i) = tbl{i+1,2};
    end
    if size(tbl,2) >= 3 && isnumeric(tbl{i+1,3})
        df(i) = tbl{i+1,3};
    end
    if size(tbl,2) >= 4 && isnumeric(tbl{i+1,4})
        MS(i) = tbl{i+1,4};
    end
    if size(tbl,2) >= 5 && isnumeric(tbl{i+1,5})
        Fval(i) = tbl{i+1,5};
    end
    if size(tbl,2) >= 6 && isnumeric(tbl{i+1,6})
        pval(i) = tbl{i+1,6};
    end
end

anovaTbl = table(rawTerms, SS, df, MS, Fval, pval, ...
    'VariableNames', {'Term','SS','df','MS','F','p'});

% Effect sizes: partial eta^2
idxErr = find(strcmpi(rawTerms, 'Error'), 1);

if isempty(idxErr) || isnan(SS(idxErr))
    warning('Could not locate Error row in ANOVA table. Effect sizes not computed.');
    effectTbl = table(strings(0,1), [], [], ...
        'VariableNames', {'Term','partialEta2','cohensF'});
    return;
end

SSerr = SS(idxErr);

effectIdx = 1:(idxErr-1);
effectTerms = rawTerms(effectIdx);

eta2 = SS(effectIdx) ./ (SS(effectIdx) + SSerr);
cohensF = sqrt(eta2 ./ max(1 - eta2, eps));

effectTbl = table(effectTerms, eta2, cohensF, ...
    'VariableNames', {'Term','partialEta2','cohensF'});

end