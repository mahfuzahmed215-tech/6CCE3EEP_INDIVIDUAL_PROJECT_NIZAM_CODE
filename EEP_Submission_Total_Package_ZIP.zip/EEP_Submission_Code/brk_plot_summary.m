function fig = brk_plot_summary(perCond, criteria, cfg)
% brk_plot_summary  Summary bar charts (μ and ΔT) with pass/fail annotations.

% Sort for consistent plotting
[~,ord] = sortrows([perCond.texture perCond.environment],[1 2]);
perCond = perCond(ord,:);
criteria = criteria(ord,:);

labels = perCond.texture + " | " + perCond.environment;
x = categorical(labels);
x = reordercats(x, labels);

fig = figure("Color","w");
tiledlayout(fig,2,1,"TileSpacing","compact","Padding","compact");

% ---------- μ ----------
nexttile;
bar(x, perCond.mu_mean); hold on;
errorbar(x, perCond.mu_mean, perCond.mu_sd, ".");
ylabel("Mean \mu"); title("\mu by condition (mean \pm SD)");
xtickangle(20);

% PASS/FAIL text
for i = 1:height(criteria)
    y = perCond.mu_mean(i) + perCond.mu_sd(i) + 0.02*max(perCond.mu_mean);
    if criteria.mu_pass_5pct(i)
        txt = "PASS";
    else
        txt = "FAIL";
    end
    text(x(i), y, txt, "HorizontalAlignment","center");
end

% ---------- ΔT ----------
nexttile;
if ismember("dT_p95_mean", perCond.Properties.VariableNames)
    yv = perCond.dT_p95_mean; ev = perCond.dT_p95_sd;
    ylab = "ΔT (\circC) = T95 − T0";
else
    yv = perCond.dT_max_mean; ev = perCond.dT_max_sd;
    ylab = "ΔT (\circC) = Tmax − T0";
end
bar(x, yv); hold on;
errorbar(x, yv, ev, ".");
ylabel(ylab); title("Temperature rise by condition (mean \pm SD)");
xtickangle(20);

end
