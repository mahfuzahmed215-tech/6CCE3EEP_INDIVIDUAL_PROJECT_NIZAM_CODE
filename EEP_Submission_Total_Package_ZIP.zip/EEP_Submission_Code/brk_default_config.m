function cfg = brk_default_config()
% brk_default_config  Default configuration for the TriboLab brake-pad pipeline.
%
% You can override any field in run_brakepad_analysis.m.

cfg = struct();

% ---------- Import ----------
cfg.encodingCandidates = ["UTF-8","ISO-8859-1","Windows-1252"];
cfg.forceDelimiter = "";  % set to "," or ";" or "\t" to force

% Candidate column names (case-insensitive; also supports contains-matching)
cfg.colTimeCandidates   = ["T","Time","time","Seconds","sec"];
cfg.colLoadCandidates   = ["Fz","NormalLoad","Normal Force","Load","Fn","Fnormal"];
cfg.colTorqueCandidates = ["Tz","Torque","Mz","Moment"];
cfg.colTangentialForceCandidates = ["Ft","FrictionForce","Friction Force","Fx","Fy","TangentialForce"];
cfg.colRPMCandidates    = ["V2","RPM","Speed","Velocity","SpindleSpeed"];
cfg.colTempPadCandidates  = ["Tpad","PadTemp","TempPad","Temperature1"];
cfg.colTempDiscCandidates = ["Tdsk","DiscTemp","TempDisc","Temperature2"];
cfg.colCOFCandidates    = ["COF","COF_T","COF-T","mu","FrictionCoefficient"];

cfg.cofScaleIfMedianAbove = 5;   % Bruker sometimes stores μ×1000

% ---------- Geometry ----------
% Use metadata radius if available; otherwise override with cfg.trackRadius_m.
cfg.trackRadius_m = NaN;         % metres
cfg.useRadiusFromMetadata = true;

% Apparent specimen area (for nominal pressure reporting)
cfg.specimenArea_m2 = 1.0e-4;    % default 10 mm × 10 mm

% ---------- Filtering & quality ----------
cfg.applyMovingMean = true;
cfg.movingMeanWindow_s = 0.20;
cfg.spikeDetection = true;
cfg.spikeMethod = "mad";         % "mad" or "std"
cfg.spikeThreshold = 8;
cfg.replaceSpikesWithNaN = true;
cfg.maxNaNFracAllowed = 0.02;
cfg.minSegmentSamples = 50;

% ---------- Segmentation ----------
cfg.loadDetectMin_N = 5;
cfg.speedDetectMin_RPM = 100;
cfg.loadSteadyFrac = 0.80;
cfg.speedSteadyFrac = 0.80;
cfg.minSteadyDuration_s = 1.0;
cfg.steadyIgnoreStart_s = 0.50;

% ---------- Temperature metrics ----------
cfg.tempChannel = "auto";     % "Tpad" / "Tdsk" / "auto"
cfg.tempBaseline_s = 0.50;
cfg.tempRobustPercentile = 95;

% ---------- Condition inference ----------
cfg.conditionMapPath = "";

% ---------- Export ----------
cfg.exportDPI = 300;
cfg.exportFormats = ["png","pdf"];

end
